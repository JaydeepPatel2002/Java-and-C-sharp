﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Sorting_A
{
    public class HeapSorter<T> : ASorter<T>
        where T : IComparable<T>
    {
        public HeapSorter(T[] array):base(array)
        { }

        public override void Sort()
        {
            // Hepify the entire array
            Heapify();
            // Foreach element in the array starting at the last, Remove it from the heap
            for (int i = array.Length - 1; i > 0; i--)
            {
                RemoveNextMax(i);
            }
        }

        /// <summary>
        /// Move the largest value to the last position of the heap
        /// Trickle the top of the heap down to its logical position
        /// </summary>
        /// <param name="lastPos"></param>
        private void RemoveNextMax(int lastPos)
        {
            // Store the largest to avariable called "max"
            T max = array[0];
            // Move the value at the end of heap to the root
            array[0] = array[lastPos];

            // Insert the max value at the end of the heap (right spot)
            array[lastPos] = max;

            // Trickle down the top of the heap
            TrickleDown(0, lastPos - 1);
        }

        /// <summary>
        /// given an array, turn it to a max heap
        /// </summary>
        private void Heapify()
        {
            // Find the index of the parent of the last element
            int parentIndex = GetParentIndex(array.Length - 1);

            // Loop backwards from the first parent to the root
            for(int index=parentIndex; index>=0; index--)
            {
                TrickleDown(index, array.Length - 1);
            }
        }

        private void TrickleDown(int index, int lastPos)
        {
            // Get a reference to the current value and trickle down
            T current = array[index];

            int largerChildIndex = GetLeftChildIndex(index);
            bool done = false;

            while(!done && largerChildIndex <= lastPos)
            {
                int rightChildIndex = GetRightChildIndex(index);
                // Which child is bigger
                if(rightChildIndex <= lastPos && array[rightChildIndex].CompareTo(array[largerChildIndex]) > 0)
                {
                    // Right child is bigger, assign its index to largerChildIndex
                    largerChildIndex = rightChildIndex;
                }

                // If the parent is less than the larger child, swap them
                if (current.CompareTo(array[largerChildIndex]) < 0)
                {
                    // Move the larger child to where the parent is
                    array[index] = array[largerChildIndex];

                    // Get ready to loop again
                    index = largerChildIndex;
                    largerChildIndex = GetLeftChildIndex(index);
                }
                else
                {
                    done = true;
                }
            }

            // Insert the trickle down element at its final position
            array[index] = current;
        }

        private int GetParentIndex(int index)
        {
            return (index - 1) / 2;
        }

        private int GetLeftChildIndex(int index)
        {
            return 2 * index + 1;
        }

        private int GetRightChildIndex(int index)
        {
            return 2 * index + 2;
        }
    }
}
