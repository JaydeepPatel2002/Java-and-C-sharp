﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorting_A
{
    public class QuickSorter<T>: ASorter<T>
        where T : IComparable<T>
    {
        public QuickSorter(T[] array) : base(array)
        { }

        public override void Sort()
        {
            QuickSortRec(0, array.Length - 1);
        }

        private void QuickSortRec(int first, int last)
        {
            //base case, 1 elemnt - do nothing

            //Recursive case 2 or more elements
            if(last - first > 0)
            {
                // Find the location of the pivot
                int pivotIndex = FindPivot(first, last);

                //Move the pivot to the rightmost position
                Swap(pivotIndex, last);

                //Partition relative to the pivot value
                int partitionIndex = Partition(first - 1, last, array[last]);

                //Swap the pivot into what the partitionIndex points to
                Swap(partitionIndex, last);

                //If the subarrays are large enough, swap different thread for each recursive call

                if(last-first > 1000)
                {
                    Parallel.Invoke(
                        // Quicksort the left half of the pivot
                        () => QuickSortRec(first, partitionIndex-1),
                        //Quicksort the right half of the pivot
                        () => QuickSortRec(partitionIndex+1, last)
                        );
                }
                else
                {
                    QuickSortRec(first, partitionIndex - 1);
                    QuickSortRec(partitionIndex + 1, last);
                }
            }
        }

        /// <summary>
        /// Partition the array defined by left and right
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <param name="pivotValue"></param>
        /// <returns></returns>
        private int Partition(int left, int right, T pivotValue)
        {
            do
            {
                //Move left pointer until we find a value greater than the pivotValue
                while (array[++left].CompareTo(pivotValue) < 0) ;
                // Move right pointer toward left until we find a value smaller then the pivotValue
                while (right>left && array[--right].CompareTo(pivotValue) > 0) ;

                Swap(left, right);
            } while (left < right);
            return left;
        }

        /// <summary>
        /// Set up a virtual method so we can override it in subclass
        /// </summary>
        /// <param name="first"></param>
        /// <param name="last"></param>
        /// <returns>Return the location of the pivot</returns>
        protected virtual int FindPivot(int first, int last)
        {
            return last;
        }
    }
}
