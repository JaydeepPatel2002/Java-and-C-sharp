﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorting_A
{
    internal class Program
    {
        public static void TestSorter(ASorter<int> Sorter)
        {
            //Display the sorter type and how many elemnents in the array
            Console.WriteLine(Sorter.GetType().Name + " With " + Sorter.Length + " elements.");

            if(Sorter.Length < 50)
            {
                Console.WriteLine("Before sort: \n" + Sorter);
            }

            long startTime =  Environment.TickCount;
            Sorter.Sort();
            long endTime = Environment.TickCount;

            if(Sorter.Length < 50)
            {
                Console.WriteLine("Afer sort: \n" + Sorter);
            }

            Console.WriteLine("Sort took " + (endTime - startTime) + " milliseconds.");
        }
        public static void SorterTest()
        {
            Console.WriteLine("Enter number of elements: ");
            string input = Console.ReadLine();

            int arraySize = Int32.Parse(input);

            int[] array = new int[arraySize];

            Random r = new Random(Environment.TickCount);

            for(int i = 0; i < arraySize; i++)
            {
                array[i] = r.Next(array.Length);
            }

            //TestSorter(new InsertionSorter<int>(array));
            //TestSorter(new QuickSorter<int>(array));
            //TestSorter(new QuickSorterMediumOfThree<int>(array));
            TestSorter(new HeapSorter<int>(array));
        }

        public static void DemoStableSort()
        {
            StableDemo[] array = new StableDemo[10];
            Random r = new Random(Environment.TickCount);

            for(int i = 0; i < array.Length; i++)
            {
                array[i] = new StableDemo(r.Next(array.Length), i);
            }

            //ASorter<StableDemo> sorter = new InsertionSorter<StableDemo>(array);

            //ASorter<StableDemo> sorter = new HeapSorter<StableDemo>(array);

            ASorter<StableDemo> sorter = new QuickSorter<StableDemo>(array);

            Console.WriteLine("Before Sort: \n" + sorter);

            sorter.Sort();

            Console.WriteLine("After Sort: \n" + sorter);
        }
        static void Main(string[] args)
        {
            //SorterTest();
            DemoStableSort();
        }
    }
}
