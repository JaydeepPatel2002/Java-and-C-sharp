
public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack oStack = new Stack(10);
		int i=0;
		for(;;)
		{
			try {
				System.out.print(oStack.push(i));
			} catch (StackOverflowException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
			assert i++<9:"Failed";
			if(i>=11) break;
		}
		
		
		try {
				while(true)
				{
						System.out.print(oStack.pop());
				}
			} catch (StackEmptyException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
	}

}
