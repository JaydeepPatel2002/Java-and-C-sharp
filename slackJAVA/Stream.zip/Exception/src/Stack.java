import java.util.ArrayList;

public class Stack {
	private ArrayList<Integer> m_aBuf;
	private int m_nSize;
	
	public Stack(int nSize)
	{
		m_nSize = nSize;
		m_aBuf= new ArrayList<>(m_nSize);
	}
	
	public int getSize()
	{
		return m_aBuf.size();
	}
	
	public int push(int nVal) throws StackOverflowException
	{
		if(m_aBuf.size()<m_nSize)
		{
			m_aBuf.add(nVal);
		}
		else
		{
			throw new StackOverflowException(m_nSize, nVal);
		}
		return nVal;
	}
	
	public int pop() throws StackEmptyException
	{
		if(m_aBuf.size()>0)
		{
			int nVal = m_aBuf.get(m_aBuf.size()-1);
			m_aBuf.remove(m_aBuf.size()-1);
			return nVal;
		}
		throw new StackEmptyException();
	}
	
}
