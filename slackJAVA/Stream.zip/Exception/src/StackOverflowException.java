
public class StackOverflowException extends Exception {
	public StackOverflowException(int nSize, int nVal)
	{
		super(String.format("The stack is limited at size %d."+ 
				"Push value %d failed.", nSize,nVal));
	}
}
