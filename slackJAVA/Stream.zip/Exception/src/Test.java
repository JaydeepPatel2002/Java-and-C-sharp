import java.io.IOException;

public class Test {

	public static void method2() throws Exception,IOException
	{
		int i = (int)(Math.random()*2);
		if (i % 2==0)
			throw new Exception();
		else
			throw new IOException();
	}
	
	public static void method1() throws Exception,IOException
	{
		method2();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			method1();
		}
		catch(IOException e)
		{
			System.out.print(e.getMessage());
		}
		catch(Exception e)
		{
			System.out.print(e.getMessage());
		}
	}

}
