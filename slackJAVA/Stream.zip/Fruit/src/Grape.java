
public class Grape extends Fruit {
	private boolean Seedness = true;
	public Grape() {
		// TODO Auto-generated constructor stub
	}

	public Grape(int w, String c, String u) {
		super(w, c, u);
		// TODO Auto-generated constructor stub
	}
	
	public Grape(int w)
	{
		super(w);
	}

	@Override
	public String toString()
	{
		return String.format("Grape Seednes = %b %s",this.Seedness,super.toString());
	}
	
	@Override
	public Grape setColor(String c)
	{
		super.setColor(c);
		return this;
	}
	
	@Override
	public Grape setCountry(String c)
	{
		super.setCountry(c);
		return this;
	}

}
