
public class Apple extends Fruit {

	public Apple() {
		// TODO Auto-generated constructor stub
	}

	public Apple(int w, String c, String u) {
		super(w, c, u);
		// TODO Auto-generated constructor stub
	}
	
	public Apple(int w)
	{
		super(w);
	}

	@Override
	public String toString()
	{
		return String.format("Apple %s",super.toString());
	}
	
	@Override
	public Apple setColor(String c)
	{
		super.setColor(c);
		return this;
	}
	
	@Override
	public Apple setCountry(String c)
	{
		super.setCountry(c);
		return this;
	}
}
