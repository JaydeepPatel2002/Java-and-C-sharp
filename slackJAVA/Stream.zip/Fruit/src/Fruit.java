import java.util.List;

public class Fruit {
	private int Weight;
	private String Color;
	private String Country;

	static public <T> void print(List<T> list)
	{
		for(T f: list) System.out.println(f);
	}
	
	public Fruit() {
		// TODO Auto-generated constructor stub
		Weight = 0;
		Color = "";
		Country = "";
	}
	
	public Fruit(int w)
	{
		this();
		this.Weight = w;
	}
	
	public Fruit(int w,String c, String u)
	{
		this.Weight = w;
		this.Color = c;
		this.Country = u;
	}
	
	public int getWeight() {return this.Weight;}
	public String getColor() {return this.Color;}
	public String getCountry() {return this.Country;}

	public Fruit setColor(String c)
	{
		this.Color = c;
		return this;
	}
	
	public Fruit setCountry(String c)
	{
		this.Country = c;
		return this;
	}
	
	@Override
	public String toString()
	{
		return String.format("Weight = %d Color = %s Country = %s", this.Weight,this.Color,this.Country);
	}
}

