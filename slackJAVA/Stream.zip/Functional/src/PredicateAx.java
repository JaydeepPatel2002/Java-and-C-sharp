@FunctionalInterface
public interface PredicateAx<T,E> {
	boolean test(T a,E val);
}
