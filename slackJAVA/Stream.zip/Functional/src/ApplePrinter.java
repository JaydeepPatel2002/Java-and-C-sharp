
public interface ApplePrinter {
	void print(Apple a);
}
