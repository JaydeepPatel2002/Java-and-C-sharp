
public class ApplePredicatebyColorGreen implements ApplePredicate {

	@Override
	public boolean test(Apple a) {
		// TODO Auto-generated method stub
		return "green".equals(a.getColor());
	}

}
