
public class ApplePredicatebyHeavy implements ApplePredicate {

	@Override
	public boolean test(Apple a) {
		// TODO Auto-generated method stub
		return a.getWeight()>100.0;
	}

}
