
public class ApplePredicatebyGreenHeavy implements ApplePredicate {

	@Override
	public boolean test(Apple a) {
		// TODO Auto-generated method stub
		return "green".equals(a.getColor()) && a.getWeight()>=100.0;
	}

}
