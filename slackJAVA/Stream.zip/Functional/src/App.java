import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class App {

	public static String CLR = "green";
	public String targer_color = CLR;
	
	
	
	
	
	public void my_filter(List<Apple> list,double weight)
	{
		String color = "green";
		List<Apple> rrlist = filterApplex(list,(a, clr)->((Apple)a).getWeight()>weight,color);
		color = "red";
		
		printApple(rrlist, new FancyApplePrinter());
		
		List<String> str = Arrays.asList("a","b","A","B");
		str.sort((s1, s2) -> s1.compareToIgnoreCase(s2));
		str.sort(String::compareToIgnoreCase);
		str.sort(Comparator.comparing(String::toUpperCase));
		
	}
	
	public static <T> List<Apple> map(List<T> list, Function<T, Apple> f)
	{
		List<Apple> rs= new ArrayList<>();
		for(T d: list)
		{
			rs.add(f.apply(d));
		}
		return rs;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Apple> alist = map(Arrays.asList(1d,2d,3d,4d,5d,6d,6d,7d),Apple::new);
		printApple(alist, new FancyApplePrinter());
		
		List<Apple> list = new ArrayList<>();
		list.add(new Apple("green",10.0));
		list.add(new Apple("red",20.0));
		list.add(new Apple("white",30.0));
		list.add(new Apple("green",50.0));
		list.add(new Apple("green",70.0));
		list.add(new Apple("red",100.0));
		list.add(new Apple("red",110.0));
		list.add(new Apple("green",1220.0));
		list.add(new Apple("red",105.0));
		//printApple(list, new BasicApplePrinter());
		
		//List<Apple> ghlist = FilterApple(list, new ApplePredicatebyGreenHeavy());
		//printApple(ghlist, new FancyApplePrinter());
		
		//Now we need red apples
/*		
		List<Apple> rlist = FilterApple(list, new ApplePredicate()
				{
					public boolean test(Apple a)
					{
						return "red".equals(a.getColor());
					}
			
				}
				);
*/
		//List<Apple> rlist = FilterApple(list,(Apple a)->"red".equals(a.getColor()));
		//printApple(rlist, new FancyApplePrinter());
		
		
		//Now we need red heavy apples
/*		
		List<Apple> rhlist = FilterApple(list,new ApplePredicate()
				{
					public boolean test(Apple a)
					{
						return "red".equals(a.getColor()) && a.getWeight()>=100.0;
					}
				}
				);
*/				
		//List<Apple> rhlist = FilterApple(list,(Apple a)->"red".equals(a.getColor()) && a.getWeight()>=100.0);
		//printApple(rhlist, new FancyApplePrinter());
				
		List<Apple> rrlist = filterApplex(list,(a, clr)->((Apple)a).getColor().equals(clr),CLR);
		//printApple(rrlist, new FancyApplePrinter());
		
		//list.sort((Apple o1, Apple o2)->(int)(o1.getWeight() - o2.getWeight()));
		
		/*
		list.sort( new Comparator<Apple>()
				{
					@Override
					public int compare(Apple o1, Apple o2) {
						// TODO Auto-generated method stub
						return (int)(o1.getWeight() - o2.getWeight());
					}
			
				}
				);
				*/
		//printApple(list, (Apple a)->System.out.printf("%f %s\n", a.getWeight(),a.getColor()));
	}
	
	//FilterApple(apples, new ApplePredicatebyColorGreen());
		//FilterApple(apples, new ApplePredicatebyHeavy());
		//FilterApple(apples, new ApplePredicatebyGreenHeavy());
		public static List<Apple> FilterApple(List<Apple> Inventory,Predicate<Apple> p)
		{
			List<Apple> rs = new ArrayList<>();
			for(Apple a : Inventory)
			{
				if(p.test(a))
				{
					rs.add(a);
				}
			}
			return rs;
		}

	public static List<Apple> filterGreenApple(List<Apple> Inventory)
	{
		List<Apple> rs = new ArrayList<>();
		for(Apple a : Inventory)
		{
			if("green".equals(a.getColor()))
			{
				rs.add(a);
			}
		}
		return rs;
	}

	public static List<Apple> filterApplebyColor(List<Apple> Inventory,String color)
	{
		List<Apple> rs = new ArrayList<>();
		for(Apple a : Inventory)
		{
			if(color.equals(a.getColor()))
			{
				rs.add(a);
			}
		}
		return rs;
	}
	
	
	public static <T,E> List<T> filterApplex(List<T> Inventory, PredicateAx<T,E> p,E val)
	{
		List<T> rs = new ArrayList<>();
		/*
		for(T a : Inventory)
		{
			if (p.test(a, val)) rs.add(a);
				
		}*/
		Inventory.forEach(a->{if (p.test(a, val)) rs.add(a);});
		return rs;
	}
	
	
	
	public static List<Apple> filterApplebyWeight(List<Apple> Inventory,double weight)
	{
		List<Apple> rs = new ArrayList<>();
		for(Apple a : Inventory)
		{
			if(a.getWeight()>=weight)
			{
				rs.add(a);
			}
		}
		return rs;
	}
	
	public static List<Apple> filterApple(List<Apple> Inventory,String color, double weight,boolean byColor)
	{
		List<Apple> rs = new ArrayList<>();
		for(Apple a : Inventory)
		{
			boolean choosed = byColor?a.getColor().equals(color):a.getWeight()>=weight;
			if(choosed)
			{
				rs.add(a);
			}
		}
		return rs;
	}
	
	
	
	//printApple(apples, new BasicApplePrinter());
	//printApple(apples, new FancyApplePrinter());
	public static void printApple(List<Apple> Inventory,ApplePrinter p)
	{
		for(Apple a : Inventory)
		{
			p.print(a);
		}
	}
}
