//color.equals(a.getColor())
//a.getWeight()>=weight

public interface ApplePredicate {
	boolean test(Apple a);
}
