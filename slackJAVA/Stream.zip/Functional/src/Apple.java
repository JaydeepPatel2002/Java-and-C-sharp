
public class Apple {
	private double m_dWeight = 0;
	private String m_sColor;
	
	public Apple()
	{
		
	}
	
	public Apple setColorex(String clr)
	{
		this.m_sColor = clr;
		return this;
	}
	
	public Apple(String c, double w)
	{
		this.m_dWeight=w;
		this.m_sColor=c;
	}
	public Apple(double w)
	{
		this.m_dWeight=w;
	}
	public double getWeight() {return this.m_dWeight;}
	public void setWeight(double w) {this.m_dWeight=w;}
	public String getColor() {return this.m_sColor;}
	public void setColor(String c){this.m_sColor=c;}
	
}
