
public class BasicApplePrinter implements ApplePrinter{

	@Override
	public void print(Apple a) {
		// TODO Auto-generated method stub
		System.out.println(a.getColor()+" Apple");
	}

}
