
public class FancyApplePrinter implements ApplePrinter{

	@Override
	public void print(Apple a) {
		// TODO Auto-generated method stub
		System.out.printf("%s with weight %f g\n",a.getColor()+" Apple",a.getWeight());
	}

}
