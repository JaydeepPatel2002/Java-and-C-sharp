import java.util.Collections;
import java.util.PriorityQueue;

public class Comp {
	
		public static void main(String[] args) {
		    PriorityQueue<String> queue1 = new PriorityQueue<>();
		    queue1.offer("Oklahoma");
		    queue1.offer("Indiana");
		    queue1.offer("Georgia");
		    queue1.offer("Texas");

		    System.out.println("Priority queue using Comparable:");
		    while (queue1.size() > 0) {
		      System.out.print(queue1.remove() + " ");
		    }

		    PriorityQueue<String> queue2 = new PriorityQueue<>(
		      4, Collections.reverseOrder());
		    queue2.offer("Oklahoma");
		    queue2.offer("Indiana");
		    queue2.offer("Georgia");
		    queue2.offer("Texas");

		    System.out.println("\nPriority queue using Comparator:");
		    while (queue2.size() > 0) {
		      System.out.print(queue2.remove() + " ");
		    }
	  }

	 public static class MyComparator3 implements
	  java.util.Comparator<String> {
		    @Override
		    public int compare(String s1, String s2) {
		      return new StringBuilder(s1).reverse().toString().compareTo(new StringBuilder(s2).reverse().toString());
		    }
		  }
	
	  public static class MyComparator1 implements
	  java.util.Comparator<String> {
		    @Override
		    public int compare(String s1, String s2) {
		      return s1.toLowerCase().compareTo(s2.toLowerCase());
		    }
		  }
	
	  public static class MyComparator implements
	      java.util.Comparator<String> {
	    @Override
	    public int compare(String s1, String s2) {
	      return s1.length() - s2.length();
	    }
	  }
}
