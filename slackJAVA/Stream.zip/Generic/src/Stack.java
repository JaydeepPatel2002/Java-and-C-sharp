interface Stackable{
	
}


public class Stack<E> {
	private java.util.ArrayList<E> list;
	
	private static int nCount = 0;
	public Stack()
	{
		list = new java.util.ArrayList<>();
		nCount++;
		
	}
	
	public int getSize() { return list.size();}
	
	public boolean isEmpty() {return getSize()==0;}
	
	public void push(E o)
	{
		if(o instanceof Stackable)
			list.add(o);
	}
	
	public E peek()
	{
		if(isEmpty()) return null;
		E oRs = list.get(0);
		return oRs;
	}
	
	public E pop()
	{
		if(isEmpty()) return null;
		E oRs = list.get(0);
		list.remove(0);
		return oRs;
	}
	
	public static <T> void printStack(Stack<T> oStack)
	{
		System.out.println(nCount);
		for(T o:oStack.list)
		{
			System.out.println(o);
		}
	}
	
	public <T> void printOtherStack(Stack<T> oStack)
	{
		System.out.println(nCount);
		for(T o:oStack.list)
		{
			System.out.println(o);
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> oStack = new Stack<String>();
		printStack(oStack);//1
		oStack.push("asdd");
		oStack.push("1234");
		Stack<Integer> oStack1 = new Stack<Integer>();
		printStack(oStack1);//2
		
	}

}
