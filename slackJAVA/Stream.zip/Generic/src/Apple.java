
public class Apple extends Fruit {
	int nWeight;
	public Apple(String clr, int weight)
	{
		super(clr);
		this.nWeight = weight;
	}
	
	@Override 
	public String toString()
	{
		return String.format("%s Apple %d", super.toString(),nWeight);
	}

}
