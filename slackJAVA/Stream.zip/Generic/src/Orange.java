
public class Orange extends Fruit {
	float dWeight;
	public Orange(String clr, float weight)
	{
		super(clr);
		this.dWeight = weight;
	}
	
	@Override 
	public String toString()
	{
		return String.format("%s Orange %3.1f", super.toString(),dWeight);
	}
}
