import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

class StrComparetor implements Comparator<String>{

	@Override
	public int compare(String o1, String o2) {
		// TODO Auto-generated method stub
		return o1.length()-o2.length();
	}


}

public class Sets {
	
	public static <T extends Number> void preparetestSetPerf(Set<T> set1)
	{
		long start = System.nanoTime();
		
		//Add 10000 random ints(range 0-100000) to each set
		for(int i = 0;i<10000;i++)
		{
			int nVal = (int)(Math.random()*100000d);
			set1.add((T)(Number)nVal);
		}
		long esp = System.nanoTime() - start;
		System.out.println(esp);
	}
	
	
	public static <T extends Number> void testSetPerfRemove(Set<T> set1)
	{
		long start = System.nanoTime();
		
		//Remove each int from each set
		Iterator <T> iter = set1.iterator();
		while(iter.hasNext())
		{
			if(iter.next()!=null)iter.remove();
		}
		long esp = System.nanoTime() - start;
		System.out.println(esp);
	}
	
	public static <T extends Number> void testSetPerfSum(Set<T> set1)
	{
		long start = System.nanoTime();
		Iterator <T> iter = set1.iterator();
		int nSum=0;
		while(iter.hasNext())
		{
			if(iter.next()!=null) nSum+=(Integer)iter.next();
		}
		long esp = System.nanoTime() - start;
		System.out.println(esp);
	}
	
	
	
	public static void main(String[] args) {
/*		
		Set<Integer> set1 = new HashSet<>();
		Set<Integer> set2 = new LinkedHashSet<>();
		
		preparetestSetPerf(set1);
		testSetPerfSum(set1);
		testSetPerfRemove(set1);
		
		preparetestSetPerf(set2);
		testSetPerfSum(set2);
		testSetPerfRemove(set2);
*/
		
		Set<String> set = new HashSet<>();

	    // Add strings to the set
	    set.add("London");
	    set.add("Paris");
	    set.add("New York");
	    set.add("San Francisco");
	    set.add("Beijing");
	    set.add("New York");

	    TreeSet<String> treeSet = new TreeSet<>(new StrComparetor());
	    treeSet.addAll(set);
	    System.out.println("Sorted tree set: " + treeSet);

	    // Use the methods in SortedSet interface
	    System.out.println("first(): " + treeSet.first());
	    System.out.println("last(): " + treeSet.last());
	    System.out.println("headSet(\"New York\"): " + 
	      treeSet.headSet("New York"));
	    System.out.println("tailSet(\"New York\"): " + 
	      treeSet.tailSet("New York"));

	    // Use the methods in NavigableSet interface
	    System.out.println("lower(\"P\"): " + treeSet.lower("P"));
	    System.out.println("higher(\"P\"): " + treeSet.higher("P"));
	    System.out.println("floor(\"P\"): " + treeSet.floor("P"));
	    System.out.println("ceiling(\"P\"): " + treeSet.ceiling("P"));
	    System.out.println("pollFirst(): " + treeSet.pollFirst());
	    System.out.println("pollLast(): " + treeSet.pollLast());
	    System.out.println("New tree set: " + treeSet);
	
	}
}
