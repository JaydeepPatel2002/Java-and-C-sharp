import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Queue;

public class Basket {
	
	public static void showBasket(Collection<? extends Fruit> basket)
	{
		for(Fruit o: basket)
		{
			System.out.println(o.toString());
		}
	}
	
	public static <T extends Fruit> void mergeBasket1(ArrayList<T> src,
			ArrayList<T> dst)
	{
		for(T o: src)
		{	
			dst.add(o);
		}
	}
	
	
	public static ArrayList<Fruit> mergeBasket(ArrayList<?  extends Fruit> basket1,ArrayList<?  extends Fruit> basket2)
	{
		ArrayList<Fruit> rs = new ArrayList<>();
	
		for(Fruit o: basket1)
		{	
			rs.add(o);
		}
		for(Fruit o: basket2)
		{
			rs.add(o);
		}
		return rs;		
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Apple> basketApple = new ArrayList<>();
		ArrayList<Apple> basketApple1 = new ArrayList<>();
		ArrayList<Fruit> basketOrange = new ArrayList<>();
		basketApple.add(new Apple("Red",1));
		basketApple.add(new Apple("Gree",2));
		basketApple.add(new Apple("White",3));
		basketApple1.add(new Apple("Red",1));
		basketApple1.add(new Apple("Gree",2));
		basketApple1.add(new Apple("White",3));
		
		showBasket(basketApple);
		
		basketOrange.add(new Orange("Gree",20f));
		basketOrange.add(new Orange("White",30f));
		basketOrange.add(new Orange("yellow",10.0f));
		
		
		showBasket(basketOrange);
		mergeBasket1(basketApple, basketApple1);
		showBasket(basketOrange);
		
		Queue<String> oQueue = new java.util.LinkedList<String>();
		
		
	}

}
