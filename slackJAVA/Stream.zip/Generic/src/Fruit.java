
public class Fruit {
	private String sColor;
	
	public Fruit(String clr)
	{
		this.sColor = clr;
	}
	
	
	@Override 
	public String toString()
	{
		return String.format("Fruit %s",sColor);
	}
}
