
public class ReadFailedException extends Exception {
	public ReadFailedException(int nNeeds,int nGot)
	{
		super(String.format("Need to read %d bytes but got %d bytes.",
				nNeeds,nGot));
	}
}
