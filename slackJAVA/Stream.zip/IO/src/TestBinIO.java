import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestBinIO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (  // Create an output stream to the file
			      FileOutputStream output = new FileOutputStream("temp.dat");
			 ) {
			
			      // Output values to the file
				      for (int i = 1; i <= 10; i++)
				        output.write(i*10000+i);
				      
				      
				    } catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			    try (
			      // Create an input stream for the file
			      FileInputStream input = new FileInputStream("temp.dat");
			    ) {
			      // Read values from the file
				      int value;
				      while ((value = input.read()) != -1)
				        System.out.print(value + " ");
				      
				    } catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
