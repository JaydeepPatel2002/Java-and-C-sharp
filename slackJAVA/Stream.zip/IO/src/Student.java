import java.io.Serializable;

public class Student implements Serializable {
	private String m_sName;
	private String m_sAddr;
	private int m_nAge;
	private boolean m_inClass;
	private float m_fGPA;
	
	public Student(String Name, String Addr, int Age, boolean inClass, float GPA)
	{
		this.m_fGPA= GPA;
		this.m_inClass = inClass;
		this.m_nAge = Age;
		this.m_sAddr = Addr;
		this.m_sName = Name;
	}
	
	public String getName() {return this.m_sName;}
	public String getAddr() {return this.m_sAddr;}
	public int getAge() {return this.m_nAge;}
	public boolean inClass() {return this.m_inClass;}
	public float getGPA() {return this.m_fGPA;}
	@Override
	public String toString()
	{
		return String.format("\nName:%s\nAge:%d\nGAP:%f\nInClass:%b\n", this.m_sName,this.m_nAge,this.m_fGPA,this.m_inClass);
	}
}
