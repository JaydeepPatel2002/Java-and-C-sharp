import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SharedWords {

	private static void readContent(Scanner oScanner,ArrayList<String> oList)
	{
		String sVal;
		while(oScanner.hasNext())
		{
			sVal = oScanner.nextLine().toLowerCase();
			String[] sVals = sVal.split("[\\p{Punct}\\s]+");
			oList.addAll(Arrays.asList(sVals));
		}
	}
	
	private static void Process(ArrayList<String> oaInput1,
			ArrayList<String> oaInput2, 
			ArrayList<String>oaOutput)
	{
		for(String sWord: oaInput1)
		{
			if(oaInput2.indexOf(sWord)>=0)
			{
				if(oaOutput.indexOf(sWord)<0)
				{
					oaOutput.add(sWord);
				}
			}
		}
	}
	
	private static void writeContent(PrintWriter oWriter, ArrayList<String> oList)
	{
		for(String sVal: oList)
		{
			oWriter.println(sVal);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length!=3)
		{
			System.out.println("Usage: Sharedwords file1 file2 output_file");
			System.exit(1);
		}
		File oFile1 = new File(args[0]);
		if(!oFile1.exists())
		{
			System.out.printf("%s is not exist.\n",args[0]);
			System.exit(2);
		}
		File oFile2 = new File(args[1]);
		if(!oFile2.exists())
		{
			System.out.printf("%s is not exist.\n",args[1]);
			System.exit(2);
		}
		File oFile3 = new File(args[2]);
		if(oFile3.exists())
		{
			System.out.printf("%s is exist and will be backuped.\n",args[2]);
			oFile3.renameTo(new File(String.format("%s.bak", args[2])));
			//oFile3.delete();
		}
		ArrayList<String> oaInput1 = new ArrayList<>(256);
		ArrayList<String> oaInput2 = new ArrayList<>(256);
		ArrayList<String> oaOutput = new ArrayList<>(128);
		
		//Read the content from two input files
		try (
				Scanner oScanner1 = new Scanner(oFile1);
				Scanner oScanner2 = new Scanner(oFile2);
				)
		{
			readContent(oScanner1,oaInput1);
			readContent(oScanner2,oaInput2);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(3);
		}
		//Process the data
		Process(oaInput1,oaInput2,oaOutput);
		oaOutput = (ArrayList<String>) oaOutput.stream().filter(s->s.length()>3).collect(Collectors.toList());
		//Write the results to the output file
		try (
				PrintWriter oWriter = new PrintWriter(oFile3);
				)
		{
			writeContent(oWriter,oaOutput);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(3);
		}
		
		

		
	}

}
