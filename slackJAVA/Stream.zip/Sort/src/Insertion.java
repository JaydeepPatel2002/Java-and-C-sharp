import java.util.Arrays;

public class Insertion {

	public static void sort(int[] data)
	{
		for(int i=1;i<data.length;i++)
		{
			int nValue = data[i];
			insert(data,nValue,i);
		}
	}
		
	public static void insert(int[] data, int nVal,int nIndex)
	{	
		int i=0;
		for(i=nIndex-1;i>=0;i--)
		{
			if(data[i]>nVal)
			{
				break;
			}
			data[i+1] = data[i];
		}
		data[i+1]=nVal;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] naVal = new int[10];
		for(int i = 0;i<naVal.length;i++)
		{
			naVal[i]=(int)(Math.random()*100);
		}
		System.out.println(Arrays.toString(naVal));
		sort(naVal);
		System.out.println(Arrays.toString(naVal));
	}

}


