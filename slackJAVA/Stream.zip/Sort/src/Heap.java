import java.util.Arrays;

public class Heap {
	private java.util.ArrayList<Integer> m_aList = new java.util.ArrayList<>();
	
	public Heap()
	{
		
	}
	
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder("[");
		
		for(int nVal:m_aList)
		{
			sb.append(nVal);
			sb.append(",");
		}
		sb.append("]");
		return sb.toString();
	}
	
	public int getSize()
	{
		return m_aList.size();
	}
	
	public boolean isEmpty()
	{
		return getSize()==0;
	}
	
	public void add(int nVal)
	{
		//1. Add this new val as the last leaf of tree
		m_aList.add(nVal);
		//2. Do the swap up op with the new node
		int nCurrentIndex = m_aList.size()-1;
		
		while(nCurrentIndex>0)
		{
		
			int nParentIndex = (nCurrentIndex-1)/2;
			
			//If child is greater than the parent, we swap up
			if(m_aList.get(nCurrentIndex)>m_aList.get(nParentIndex))
			{
				int nTemp = m_aList.get(nCurrentIndex);
				m_aList.set(nCurrentIndex, m_aList.get(nParentIndex));
				m_aList.set(nParentIndex, nTemp);
			}
			else
			{
				//Done it is a heap now
				break;
			}
			nCurrentIndex = nParentIndex;
		}		
	}
	
	public int removeRoot()
	{
		if (isEmpty()) return -1;
		int nRs = m_aList.get(0);
		KeepItasHeapAfterRemove();
		return nRs;
	}
	
	private void KeepItasHeapAfterRemove()
	{
		//Move the last leaf to the root
		m_aList.set(0, m_aList.get(getSize()-1));
		//Remove the last leaf
		m_aList.remove(getSize()-1);
		
		int nCurrentIndex =0;
		while(nCurrentIndex<m_aList.size())
		{
			//Find which child is greater
			int nLeftChild = 2*nCurrentIndex+1;
			int nRightChild = 2*nCurrentIndex+2;
			if(nLeftChild>=m_aList.size()) break;
			
			int nMaxChild = nLeftChild;
			
			if(nRightChild<m_aList.size() && 
					m_aList.get(nRightChild)>m_aList.get(nLeftChild))
			{
				nMaxChild = nRightChild;
			}
			//If the parent(current)<child(max) swap down
			if(m_aList.get(nCurrentIndex)<m_aList.get(nMaxChild))
			{
				int nTemp = m_aList.get(nCurrentIndex);
				m_aList.set(nCurrentIndex, m_aList.get(nMaxChild));
				m_aList.set(nMaxChild, nTemp);
			}
			else
			{
				//Done it is a heap
				break;
			}
			nCurrentIndex = nMaxChild;
		}
	}
	
	public static void sort(int[] data)
	{
		Heap oHeap = new Heap();
		for(int nVal:data) oHeap.add(nVal);
		int i=0;
		while(!oHeap.isEmpty())
		{
			data[i++] = oHeap.removeRoot();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] naVal = new int[10];
		for(int i = 0;i<naVal.length;i++)
		{
			naVal[i]=(int)(Math.random()*100);
		}
		System.out.println(Arrays.toString(naVal));
		sort(naVal);
		System.out.println(Arrays.toString(naVal));
	}
}

