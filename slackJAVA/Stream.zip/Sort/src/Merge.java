import java.util.Arrays;

public class Merge {

	public static void sort(int[] data)
	{
		if (data.length<=1) return;
		int [] naLeft = new int[data.length/2];
		System.arraycopy(data, 0, naLeft, 0, naLeft.length);
		int [] naRight = new  int[data.length-naLeft.length];
		System.arraycopy(data, naLeft.length, naRight, 0,naRight.length);
		
		sort(naLeft);
		sort(naRight);
		
		merge(naLeft,naRight,data);
		
	}
	
	public static void merge(int[] naLeft, int[]naRight, int[] data)
	{
		int nLeft = 0;
		int nRight = 0;
		int nData = 0;
		while(nLeft<naLeft.length && nRight<naRight.length)
		{
			if(naLeft[nLeft]<naRight[nRight])
			{
				data[nData++] = naLeft[nLeft++];
			}
			else
			{
				data[nData++] = naRight[nRight++];
			}
		}
		while(nLeft<naLeft.length) data[nData++] = naLeft[nLeft++];
		while(nRight<naRight.length)data[nData++] = naRight[nRight++];
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] naVal = new int[10];
		for(int i = 0;i<naVal.length;i++)
		{
			naVal[i]=(int)(Math.random()*100);
		}
		System.out.println(Arrays.toString(naVal));
		sort(naVal);
		System.out.println(Arrays.toString(naVal));
	}
}
