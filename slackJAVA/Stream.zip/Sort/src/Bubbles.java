import java.util.Arrays;

public class Bubbles {
	
	public static void sort(int[] data)
	{
		boolean bSorted = false;
		for(int i=1;i<data.length;i++)
		{
			bSorted = true;
			for(int j=0;j<data.length-i;j++)
			{
				if(data[j]>data[j+1])
				{
					int nTemp=data[j];
					data[j] = data[j+1];
					data[j+1] = nTemp;
					bSorted = false;
				}
			}
			if(bSorted) break;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] naVal = new int[10];
		for(int i = 0;i<naVal.length;i++)
		{
			naVal[i]=(int)(Math.random()*100);
		}
		System.out.println(Arrays.toString(naVal));
		sort(naVal);
		System.out.println(Arrays.toString(naVal));
	}

}
