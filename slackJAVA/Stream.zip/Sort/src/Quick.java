import java.util.Arrays;

public class Quick {
	public static void sort(int[] data)
	{
		sort(data,0,data.length-1);
	}
	
	private static void sort(int[] data, int start, int end)
	{
		if(end>start)
		{
			int pivotIndex = partition(data,start,end);
			sort(data,start,pivotIndex-1);
			sort(data,pivotIndex+1,end);
		}
	}
		
	
	private static int partition(int[] data, int start, int end)
	{
		//Choose the first element as pivot
		int pivot = data[start];
		//Init low and high
		int low = start + 1;
		int high = end;

		while(high>low)
		{
			while(low<=high)
			{
				if(data[low]>pivot) break;
				low++;
			}
			while(low<=high)
			{
				if(data[high]<=pivot) break;
				high--;
			}
			if(high>low)
			{
				int nTemp = data[high];
				data[high] = data[low];
				data[low] = nTemp;
			}
		}
		//Keep moving high to left to find the spot for the pivot
		while(high>start)
		{
			if(data[high]<pivot) break;
			high--;
		}
		
		if(pivot>data[high])
		{
			//Need to swap pivot to high pos
			data[start] = data[high];
			data[high] = pivot;
			return high;
		}
		else
		{
			//First element/pivot is the largest number
			return start;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] naVal = new int[10];
		for(int i = 0;i<naVal.length;i++)
		{
			naVal[i]=(int)(Math.random()*100);
		}
		System.out.println(Arrays.toString(naVal));
		sort(naVal);
		System.out.println(Arrays.toString(naVal));
	}
}
