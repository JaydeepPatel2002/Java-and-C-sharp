
public class Factorial {
	
	//fib(0) = 0;
	//fib(1) = 1;
	//fib(n) = fib(n -1) + fib(n -2); if n >=2
	public static int fib(int n)
	{
		if (n==0) return 0;
			else if(n==1) return 1;
		else
			return fib(n-1)+fib(n-2);
	}
	
	public static boolean isPalindrome(String s) 
	{
	  if (s.length() <= 1) // Base case
	    return true;
	  else if (s.charAt(0) != s.charAt(s.length() - 1)) // Base case
	    return false;
	  else
	    return isPalindrome(s.substring(1, s.length() - 1));   
	}
	
	public static boolean isPalindromeLoop(String s)
	{
		for(int i=0;i<s.length()/2;i++)
		{
			if(s.charAt(i)!=s.charAt(s.length()-i-1)) return false;
		}
		return true;
	}
	
	//factorial(0) = 1;
	//factorial(n) = n*factorial(n-1);

	public static int factorial(int n)
	{
		if(n==0) return 1;
		else
			return n*factorial(n-1);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print(isPalindromeLoop("abcdedcba"));
		System.out.print(isPalindromeLoop("abcdedcba1"));
	}

}
