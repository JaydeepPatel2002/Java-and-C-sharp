﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace Graphs_A
{
    public abstract class AGraph<T> : IGraph<T>
        where T : IComparable<T>
    {
        #region Attributes
        // Store the vertices of the graph
        protected List<Vertex<T>> vertices;

        // A dictionary is a hashtable essentially
        // It support generic. We will use it to store
        // a data item index into the vertices list. This will
        // make it much more efficient to lookup
        // a vertex in the vertices list
        protected Dictionary<T, int> revLookUp;

        //Stores the number of edges
        protected int numEdges;

        // Is the graph weighted?
        protected bool isWeighted;

        // Is the graph directed?
        protected bool isDirected;
        #endregion

        #region Constructors
        public AGraph()
        {
            vertices = new List<Vertex<T>>();
            revLookUp = new Dictionary<T, int>();
            numEdges = 0;
        }
        #endregion

        #region IGraph implementation
        public int NumVertices
        {
            get
            {
                return vertices.Count;
            }
        }

        // virtual means we can override NumEdges in subclasses
        public virtual int NumEdges
        {
            get
            {
                return numEdges;
            }
        }
        #endregion
        #region Vertex methods
        public bool HasVertex(T data)
        {
            return revLookUp.ContainsKey(data);
        }
        public Vertex<T> GetVertex(T data)
        {
            if(!HasVertex(data))
            {
                throw new ApplicationException("Vertex does not exist!");
            }

            // Reverse lookup the index in the hashtable (dictionary)
            // Note that C# overload the [] operator for its dictionary
            int index = revLookUp[data];

            return vertices[index];
        }

        public void AddVertex(T data)
        {
            if(HasVertex(data))
            {
                throw new ApplicationException("The " + data + " Vertex already exists");
            }

            Vertex<T> v = new Vertex<T>(vertices.Count, data);

            vertices.Add(v);

            revLookUp.Add(data, v.Index);

            AddVertexAdjustEdges(v);
        }

        public void RemoveVertex(T data)
        {
            // If data is not the vertices list, throw an exception
            if(!HasVertex(data))
            {
                throw new ApplicationException("The Vertex " + data + " does not exist");
            }
            else // data is in the list
            {
                // Get the vertex with the data
                Vertex<T> v = GetVertex(data);
                // Remove the vertex from the vertices list
                vertices.Remove(v);
                // Remove the data from the revLookUp
                revLookUp.Remove(data);

                // Decrement the indices of the vertices that were below the removed vertex
                for(int i = v.Index; i<vertices.Count; i++)
                {
                    // Decrement the vertex's index
                    vertices[i].Index--;
                    // Decrement the correspond revLoopUp's data's index
                    revLookUp[vertices[i].Data]--;
                }
                // Tell the child class to remove any edges related to the removed vertex
                RemoveVertexAdjustEdges(v);
            }
        }

        public IEnumerable<Vertex<T>> EnumerateVertices()
        {
            return vertices;
        }
        #endregion

        #region Edge Methods
        public virtual void AddEdge(T from, T to)
        {
            // If this is the first edge, then the graph will be unweighted
            if(numEdges == 0)
            {
                isWeighted = false;
            }
            else if (isWeighted)
            {
                throw new ApplicationException("Can't add unweighted edge!");
            }

            //Create a new Edge object and add it to the graph
            Edge<T> e = new Edge<T>(GetVertex(from), GetVertex(to));

            //Add the Edge object to the graph
            AddEdge(e);
        }
        public virtual void AddEdge(T from, T to, double weight)
        {
            // If this is the 1st Edge, then the graph will be weighted
            if(numEdges == 0)
            {
                isWeighted = true;
            }
            else if(!isWeighted)
            {
                throw new ApplicationException("Can not add to the unweighted graph!");
            }

            // Create an Edge object and add it to the graph
            Edge<T> e = new Edge<T>(GetVertex(from), GetVertex(to), weight);
            AddEdge(e);
        }
        #endregion

        #region MST

        public IGraph<T> MinimumSpanningTree()
        {
            // Create an array of graph objects references
            AGraph<T>[] forest = new AGraph<T>[NumVertices];

            // Version 1
            Edge<T>[] eArray = GetAllEdges();
            Array.Sort(eArray);

            // Version 2
            // List<Edge<T>> lEdges = GetAllEdges().ToList();
            // lEdges.Sort(new EdgeComparer());

            int iTreeTo = 0;
            int iTreeFrom = 0;
            int iCurEdge = 0;

            for(int i = 0; i<NumVertices; i++)
            {
                // How to instantiate an instance of child in the parent class
                // Two methods:
                // 1. Create an abstract method calledd CreateGraph()
                // 2. Use C# reflection to return an instance of its child class
                AGraph<T> nGraph = (AGraph<T>)this.GetType().Assembly.CreateInstance(this.GetType().FullName);
                nGraph.AddVertex(vertices[i].Data);

                forest[i] = nGraph;
            }

            while(forest.Length > 1)
            {
                Edge<T> e = eArray[iCurEdge];
                iCurEdge++;

                iTreeFrom = FindTree(e.From, forest);
                iTreeTo = FindTree(e.To, forest);

                if(iTreeFrom != iTreeTo)
                {
                    forest[iTreeFrom].MergeTrees(forest[iTreeTo]);
                    forest[iTreeFrom].AddEdge(e.From.Data, e.To.Data, e.Weight);
                    forest = Timber(iTreeTo, forest);
                }
            }
            return forest[0];
        }
        /// <summary>
        /// Given the forest, remove the graph at the location "treeCut"
        /// </summary>
        /// <param name="treeCut">The location of the graph to be cut</param>
        /// <param name="forest">The array of graph</param>
        /// <returns></returns>
        private AGraph<T>[] Timber(int treeCut, AGraph<T>[] forest)
        {
            AGraph<T>[] result = new AGraph<T>[forest.Length - 1];

            int j = 0;
            for(int i=0; i<forest.Length; i++)
            {
                if(i!=treeCut)
                {
                    result[j] = forest[i];
                    j++;
                }
            }
            return result;
        }

        /// <summary>
        /// Merge treeFrom with treeTo
        /// Copy all the vertices over
        /// Copy all the edges over
        /// </summary>
        /// <param name="treeTo"></param>
        private void MergeTrees(AGraph<T> treeTo)
        {
            foreach(Vertex<T> v in treeTo.EnumerateVertices())
            {
                this.AddVertex(v.Data);
            }

            foreach(Edge<T> e in treeTo.GetAllEdges())
            {
                this.AddEdge(e.From.Data, e.To.Data, e.Weight);
            }
        }

        /// <summary>
        /// Given a forest and a vertex, find the index of the vertex in the forest
        /// </summary>
        /// <param name="objVertex">Vertex to find its graph index</param>
        /// <param name="forest"></param>
        /// <returns></returns>
        /// <exception cref="ApplicationException"></exception>
        private int FindTree(Vertex<T> objVertex, AGraph<T>[] forest)
        {
            int i = 0;

            // Check each graph until you find the target vertex
            while (!forest[i].HasVertex(objVertex.Data) && i++ < forest.Length)
            {
                ;
            }

            // If the vertex is not in the forest
            if(i == forest.Length)
            {
                throw new ApplicationException("The graph is not found!");
            }
            // Return its index
            return i;
        }

        private class EdgeComparer : IComparer<Edge<T>>
        {
            public int Compare(Edge<T> x, Edge<T> y)
            {
                return x.CompareTo(y);
            }
        }
        #endregion

        public void DepthFirstTraversal(T start, VisitorDelegate<T> whatToDo)
        {
            // Get the starting vertex
            // Reference to the current vertex just popped off the stack
            // Create a dictionary to track the vertices already visited
            // Stack of vertex objects of the current vertex, which is not visited yet

            // Push the start vertex to the stack

            // While the stack has vertices on it
            // Current vertex <-- pop item off stack
            // If the current vertex has not been visisted
            // Process the current vertices data (whatToDo)
            // Mark the current vertex as visited (add to dictionary)
            // Get a list of all neighbours of the current vertices
            // foreach neighbours in the list
            // Add to the stack if it is visisted or is already on the stack

            Vertex<T> vStart = GetVertex(start);

            Vertex<T> vCurrent;
            Dictionary<T, T> visitedVertices = new Dictionary<T, T>();
            Stack<Vertex<T>> verticesRemaining = new Stack<Vertex<T>>();

            verticesRemaining.Push(vStart);

            while(verticesRemaining.Count > 0)
            {
                vCurrent = verticesRemaining.Pop();

                if (!visitedVertices.ContainsKey(vCurrent.Data))
                {
                    whatToDo(vCurrent.Data);

                    visitedVertices.Add(vCurrent.Data, vCurrent.Data);

                    IEnumerable<Vertex<T>> vList = EnumerateNeighbours(vCurrent.Data);

                    foreach(Vertex<T> v in vList)
                    {
                        verticesRemaining.Push(v);
                    }
                }
            }
        }

        public void BreadthFirstTraversal(T start, VisitorDelegate<T> whatToDo)
        {
            // Get the starting vertex
            // Reference to the current vertex just dequeued from the queue
            // Create a dictionary to track the vertices already visited
            // Queue of vertex objects of the current vertex, which is not visited yet

            // Enqueue the start vertex to the queue

            // While the queue has vertices on it
            // Current vertex <-- pop item off queue
            // If the current vertex has not been visisted
            // Process the current vertices data (whatToDo)
            // Mark the current vertex as visited (add to dictionary)
            // Get a list of all neighbours of the current vertices
            // foreach neighbours in the list
            // Add to the queue if it is visisted or is already on the queue

            Vertex<T> vStart = GetVertex(start);

            Vertex<T> vCurrent;
            Dictionary<T, T> visitedVertices = new Dictionary<T, T>();
            Queue<Vertex<T>> verticesRemaining = new Queue<Vertex<T>>();

            verticesRemaining.Enqueue(vStart);

            while (verticesRemaining.Count > 0)
            {
                vCurrent = verticesRemaining.Dequeue();

                if (!visitedVertices.ContainsKey(vCurrent.Data))
                {
                    whatToDo(vCurrent.Data);

                    visitedVertices.Add(vCurrent.Data, vCurrent.Data);

                    IEnumerable<Vertex<T>> vList = EnumerateNeighbours(vCurrent.Data);

                    foreach (Vertex<T> v in vList)
                    {
                        verticesRemaining.Enqueue(v);
                    }
                }
            }
        }

        #region Abstract Methods
        protected abstract void AddEdge(Edge<T> e);
        public abstract void AddVertexAdjustEdges(Vertex<T> v);
        public abstract void RemoveVertexAdjustEdges(Vertex<T> v);
        protected abstract Edge<T>[] GetAllEdges();
        public abstract Edge<T> GetEdge(T from, T to);
        public abstract void RemoveEdge(T from, T to);
        public abstract bool HasEdge(T from, T to);
        public abstract IEnumerable<Vertex<T>> EnumerateNeighbours(T data);
        #endregion

        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            foreach(Vertex<T> v in EnumerateVertices())
            {
                result.Append(v + ", ");
            }

            if(vertices.Count > 0)
            {
                result.Remove(result.Length - 2, 2);
            }

            return this.GetType().Name + "\n Vertices: " + result.ToString() + "\n";
        }

        #region SSSP
        // AllPairShortest Path is used by Uber to search for the closet driver
        public IGraph<T> ShortestWeightedPath(T start, T end)
        {
            /*
             * vTable <-- new array of VertexData objects
             * startingindex <-- index of starting point
             * load vTable withinitial VertexData objects
             * set start vertex's VertexData distance to zero
             * pq <-- instantiate a priority queue
             * pq enque the starting VertexData object
             * 
             * while there are still VertexData objects in the priority queue
             *  current VertexData <-- priority Queue dequeue
             *  if the current Vertex is not know
             *      set currentVetex to know
             *          for each neighbour wVertex of currentVertex
             *              wVertexData <- get the VertexData
             *              edge <-- get the edge object connecting wVertex and the current Vertex
             *              proposedDistance <-- currentVertex distance + cost (edge's distance)
             *              if wVertexData's distance > proposedDistance
             *                  wVertexData's distance <-- proposedDistance
             *                  wVertexData's previous to currentVertex
             *                  pq enqueue wVertexData
             * return a graph with shortest path from start to end
             */
            VertexData[] vTable = new VertexData[vertices.Count];

            int iStartIndex = revLookUp[start]; //GetVertex(start).Index;

            for(int i=0; i<NumVertices; i++)
            {
                // index of vertex in table the same as index of vertex in vertices
                vTable[i] = new VertexData(vertices[i], double.PositiveInfinity, null);
            }
            vTable[iStartIndex].Distance = 0;

            PriorityQueue pq = new PriorityQueue();

            pq.Enqueue(vTable[iStartIndex]);
            
            while(!pq.IsEmpty())
            {
                VertexData vCurrent = pq.Dequeue();

                if(!vCurrent.Known)
                {
                    vCurrent.Known = true;

                    foreach (Vertex<T> wVertex in EnumerateNeighbours(vCurrent.Vertex.Data))
                    {
                        VertexData wVertexData = vTable[wVertex.Index];
                        Edge<T> eCost = GetEdge(vCurrent.Vertex.Data, wVertex.Data);

                        double proposedDistance = eCost.Weight + vCurrent.Distance;

                        if(wVertexData.Distance > proposedDistance)
                        {
                            wVertexData.Distance = proposedDistance;
                            wVertexData.Previous = vCurrent.Vertex;

                            pq.Enqueue(wVertexData);
                        }
                    }
                }

                if(vCurrent.Vertex.Equals(GetVertex(end)))
                {
                    break;
                }
            }

            //return a graph based upon the vTable

            return BuildGraph(GetVertex(end), vTable);
        }

        private IGraph<T> BuildGraph(Vertex<T> vEnd, VertexData[] vTable)
        {
            /*
             * result <-- new instance of a graph
             * add the end vertex to the result
             * dataLast <-- vTable[location of end]
             * previous <-- previous of dataLast
             * 
             * while previous is not null
             *  add previous to result
             *  add the edge from last and previous to resutl
             *  dataLast <-- vTable[location of previous]
             *  precious <-- previous of dataLast
             */

            AGraph<T> result  = (AGraph<T>)GetType().Assembly.CreateInstance(this.GetType().FullName);

            result.AddVertex(vEnd.Data);

            VertexData DataLast = vTable[vEnd.Index];
            Vertex<T> vPrevious = DataLast.Previous;

            while(vPrevious != null)
            {
                result.AddVertex(vPrevious.Data);

                Edge<T> eEdge = GetEdge(vPrevious.Data, DataLast.Vertex.Data);

                result.AddEdge(eEdge.From.Data, eEdge.To.Data, eEdge.Weight);

                DataLast = vTable[vPrevious.Index];
                vPrevious = DataLast.Previous;
            }

            return result;
        }

        /// <summary>
        /// the purpose of this class is to provide a sorted list of VertexData
        /// A call to dequeue will remove the smallest VertexData from the list
        /// Enqueue will add a VertexData to the list and then sorted
        /// This Queue is used to store all of the VertexData objects that 
        /// have had their tentative distance updataed, but are still yet unknown
        /// </summary>
        internal class PriorityQueue
        {
            private List<VertexData> list;

            public PriorityQueue()
            {
                list = new List<VertexData>();
            }

            internal void Enqueue(VertexData vData)
            {
                list.Add(vData);

                list.Sort();
            }

            internal VertexData Dequeue()
            {
                VertexData retVal = list[0];

                list.RemoveAt(0);

                return retVal;
            }

            public bool IsEmpty()
            {
                if (list.Count <= 0)
                    return true;
                else
                    return false;
            }
        }
        internal class VertexData : IComparable
        {
            public Vertex<T> Vertex;
            public double Distance;
            public Vertex<T> Previous;
            public bool Known;

            public VertexData(Vertex<T> vertex, double distance, Vertex<T> previous, bool known=false)
            {
                Vertex = vertex;
                this.Distance = distance;
                this.Previous = previous;
                this.Known = known;
            }

            public int CompareTo(object obj)
            {
                return this.Distance.CompareTo(((VertexData)obj).Distance);
            }

            public override string ToString()
            {
                return "Vertex: " + Vertex + " Distance " + Distance + " Previous " + Previous.Data;
            }
        }
        #endregion

    }
}
