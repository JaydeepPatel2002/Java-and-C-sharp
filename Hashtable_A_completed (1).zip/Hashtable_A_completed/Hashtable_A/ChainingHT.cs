﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Hashtable_A
//{
//    public class ChainingHT<K, V> : A_Hashtable<K, V>
//        where K : IComparable<K>
//        where V : IComparable<V>

//    {
//        private int iBucketCount = 0;

//        private const int iInitialSize = 0;

//        public ChainingHT()
//        {
//            oDataArray = new object[iInitialSize];
//        }

//        public override V Get(K key)
//        {
//            //value to return

//            V vReturn = default;


//            int iIndexValue = -1;
//            //get initial hash
//            int iInitialHash = HashFunction(key);
//            //if the bucket is not null 

//            if (oDataArray[iInitialHash] != null)
//            {
//                //cast the target object to an arraylist



//                ArrayList alCurrent = (ArrayList)oDataArray[iInitialHash];
//                iIndexValue = alCurrent.IndexOf(new KeyValue<K, V>(key, default(V)));

//                if (iIndexValue >= 0)
//                {
//                    vReturn = ((KeyValue<K, V>)alCurrent[iIndexValue]).Value;
//                }

//                //foreach(KeyValuePair<K, V> kvp in alCurrent)
//                //{
//                //    iIndexValue++;
//                //    if(kvp.Key.Equals(key))
//                //    {
//                //        vReturn = kvp.Value;
//                //        break;
//                //    }
//                //}

//                //create an instance of key value pair out of the key and default value of v

//            }


//            //check the index of the newly create key/value pair in the Arraylist

//            //if return index is -1 throw exception 
//            if (iIndexValue < 0)
//            {
//                throw new ApplicationException("target not found in hahtable");
//            }

//            // return vReturn
//            return vReturn;

//        }

//        public override void Add(K key, V vValue)
//        {
//            //get initial hash
//            int iInitialHash = HashFunction(key);

//            KeyValue<K, V> kv = new KeyValue<K, V>(key, vValue);

//            ArrayList alCurrent = null;

//            if (oDataArray[iInitialHash] == null)
//            {
//                alCurrent = new ArrayList();
//                oDataArray[iInitialHash] = alCurrent;
//                iBucketCount++;
//            }
//            else
//            {
//                alCurrent = (ArrayList)oDataArray[iInitialHash];

//                if (alCurrent.Contains(kv))
//                {
//                    throw new ApplicationException("key already exists in hash table!");
//                }

//                iNumCollission++;
//            }

//            alCurrent.Add(kv);
//            iCount++;
//            if (IsOverloaded())
//            {
//                ExpandHashTable();
//            }

//        }

//        private bool IsOverloaded()
//        {
//            return (iCount / (double)HTSize) > dLoadFactor;
//        }


//        private void ExpandHashTable()
//        {

//            object[] oOldArray = oDataArray;
//            oDataArray = new object[HTSize * 2];
//            iCount = 0;
//            iBucketCount = 0;
//            iNumCollission = 0;

//            for (int i = 0; i < oOldArray.Length; i++)
//            {
//                if (oOldArray[i] != null)
//                {
//                    ArrayList alCurrent = (ArrayList)(oOldArray[i]);

//                    foreach (KeyValue<K, V> kv in alCurrent)
//                    {
//                        this.Add(kv.Key, kv.Value);
//                    }

//                }
//            }



//        }


//        public override void Remove(K key)
//        {
//            V vReturn = default;


//            int iIndexValue = -1;
//            int iInitialHash = HashFunction(key);

//            if (oDataArray[iInitialHash] != null)
//            {
//                ArrayList alCurrent = (ArrayList)oDataArray[iInitialHash];
//                iIndexValue = alCurrent.IndexOf(new KeyValue<K, V>(key, default(V)));

//                if (iIndexValue >= 0)
//                {
//                    alCurrent.RemoveAt(iIndexValue);
//                    iCount--;

//                    if (alCurrent.Count == 0)
//                    {
//                        oDataArray[iInitialHash] = null;
//                        iBucketCount--;
//                    }
//                }
//            }

//            if (iIndexValue < 0)
//            {
//                throw new ApplicationException("target not found in hahtable");
//            }

//        }


//        public override String ToString()
//        {
//            StringBuilder sb = new StringBuilder();

//            for (int i = 0; i < oDataArray.Length; i++)
//            {
//                sb.Append("Bucket number :" + i + " :  ");

//                if (oDataArray[i] != null)
//                {
//                    ArrayList alCurrent = (ArrayList)oDataArray[i];

//                    foreach (KeyValue<K, V> kv in alCurrent)
//                    {
//                        sb.Append(kv.Value.ToString() + "  --> ");
//                    }
//                    sb.Remove(sb.Length - 5, 5);

//                }
//                sb.Append("\n");

//            }
//            return sb.ToString();
//        }

//        public override IEnumerator<V> GetEnumerator()
//        {
//            return new ChainEnumerator(this);
//        }

//        public override void Clear()
//        {
//            throw new NotImplementedException();
//        }

//        private class ChainEnumerator : IEnumerator<V>
//        {
//            private ChainingHT<K, V> parent;

//            private int iCurrentBucket = -1;
//            private int iCurrentKV = -1;


//            //public V Current => (

//            //                    get(

//            //                        return(

//            //                            (KeyValue<K, V>)
//            //                            (
//            //                                    (ArrayList)(parent.oDataArray[iCurrentBucket])
//            //                        )
//            //                [iCurrentKV]
//            //        ).Value;
//            //       )
//            //)
//            object IEnumerator.Current =>
//                (
//                    (
//                        (KeyValue<K, V>)
//                            (
//                                (ArrayList)(parent.oDataArray[iCurrentBucket])
//                            )[iCurrentKV]
//                    )
//                ).Value;

//            public V Current => throw new NotImplementedException();

//            public ChainEnumerator(ChainingHT<K, V> ChainingHT)
//            {
//                this.parent = ChainingHT;
//                this.iCurrentBucket = -1;
//                this.iCurrentKV = -1;
//            }

//            public void Dispose()
//            {
//                this.parent = null;
//                iCurrentBucket = -1;
//                iCurrentKV = -1;

//            }
//            public void Reset()
//            {
//                iCurrentBucket = -1;
//                iCurrentKV = -1;
//            }


//            public bool moveNext()
//            {
//                bool bMove = false;

//                if(iCurrentBucket == -1)
//                {
//                    if(findnextArrayList() == false)
//                    {
//                        return false;

//                    }
//                }

//                ++iCurrentKV;

//                ArrayList alCurrent = (ArrayList)(parent.oDataArray[iCurrentBucket]);

//                if(iCurrentKV == alCurrent.Count)
//                {
//                    //ATTEMPT TO FIND THE NEXT  ARRAYLIST
//                    bMove = findnextArrayList();

//                    if(bMove)
//                    {

//                        //move to next arraylist there fore reinitialize the count
//                        iCurrentKV = 0;
//                    }
//                    else
//                    {
//                        iCurrentKV--;
//                    }
//                }
//                else
//                {
//                    bMove =  true; 
//                }

//                return bMove;
//            }

//            private bool findnextArrayList()
//            {
//                bool bMoved = false;

//                int iTemp = iCurrentBucket;

//                while(!bMoved || iTemp < parent.oDataArray.Length - 1)
//                {
//                    iTemp++;

//                    if (parent.oDataArray[iTemp] != null)
//                    {
//                        bMoved = true;
//                        iCurrentBucket = iTemp;
//                    }
//                }
//                return false;
//            }

//            public bool MoveNext()
//            {
//                throw new NotImplementedException();
//            }
//        }

//    }

//}

//====================================================================================
//====================================================================================

using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;
using BinarySearchTree;

namespace Hashtable_A
{
    public class ChainingHT<K, V> : A_Hashtable<K, V>
        where K : IComparable<K>
        where V : IComparable<V>
    {
        private int iBucketCount = 0;
        private const int iInitialSize = 5;
        public ChainingHT()
        {
            oDataArray = new object[iInitialSize];
        }


        //===========================================================================================


        //public override void Add(K key, V vValue)
        //{
        //    //Get Initial hash
        //    int iInitialHash = HashFunction(key);
        //    KeyValue<K, V> kv = new KeyValue<K, V>(key, vValue);
        //    ArrayList alCurrent = null;
        //    //List<KeyValue<K, V>> alList = null;
        //    if (oDataArray[iInitialHash] == null)
        //    {
        //        alCurrent = new ArrayList();
        //        oDataArray[iInitialHash] = alCurrent;
        //        iBucketCount++;
        //    }
        //    else
        //    {
        //        alCurrent = (ArrayList)oDataArray[iInitialHash];
        //        if (alCurrent.Contains(kv))
        //        {
        //            throw new ApplicationException("Key already exists in the hash table!");
        //        }
        //        iNumCollission++;
        //    }
        //    alCurrent.Add(kv);
        //    iCount++;
        //    if (IsOverloaded())
        //        ExpandHashtable();
        //}
        //private bool IsOverloaded()
        //{
        //    return (iCount / (double)HTSize) > dLoadFactor;
        //}
        //private void ExpandHashtable()
        //{
        //    object[] oOldArray = oDataArray;
        //    oDataArray = new object[HTSize * 2];
        //    iCount = 0;
        //    iBucketCount = 0;
        //    iNumCollission = 0;
        //    for (int i = 0; i < oOldArray.Length; i++)
        //    {
        //        if (oOldArray[i] != null)
        //        {
        //            // BST<KeyValue<K,V>>
        //            ArrayList alCurrent = (ArrayList)(oOldArray[i]);
        //            foreach (KeyValue<K, V> kv in alCurrent)
        //            {
        //                this.Add(kv.Key, kv.Value);
        //            }
        //            iBucketCount++;
        //        }
        //    }
        //}




        #region AddBST
        //===========================================================================================
        //===========================================================================================
        //===========================================================================================
        //===========================================================================================
        //===========================================================================================


        public override void Add(K key, V vValue)
        {
            //Get Initial hash
            int iInitialHash = HashFunction(key);
            KeyValue<K, V> kv = new KeyValue<K, V>(key, vValue);
            BST<KeyValue<K, V>> alBSTcurrent = null;
            
            if (oDataArray[iInitialHash] == null)
            {
                alBSTcurrent = new BST<KeyValue<K, V>>();
               
                oDataArray[iInitialHash] = alBSTcurrent;
                iBucketCount++;
            }
            else
            {
                alBSTcurrent = (BST<KeyValue<K, V>>)oDataArray[iInitialHash];

                if (alBSTcurrent.Find(kv) != null)
                {
                    throw new ApplicationException("Key already exists in the hash table!");
                }
                iNumCollission++;
            }
            alBSTcurrent.Add(kv);
            //alCurrent.Add(kv);
            iCount++;
            if (IsOverloaded())
                ExpandHashtable();
        }

        void dosomething(KeyValue<K, V> kv)
        {

            this.Add(kv.Key, kv.Value);
            
        }



        private bool IsOverloaded()
        {
            return (iCount / (double)HTSize) > dLoadFactor;
        }
        private void ExpandHashtable()
        {
            object[] oOldArray = oDataArray;
            oDataArray = new object[HTSize * 2];
            iCount = 0;
            iBucketCount = 0;
            iNumCollission = 0;
            for (int i = 0; i < oOldArray.Length; i++)
            {
                if (oOldArray[i] != null)
                {
                    BST<KeyValue<K, V>> alBSTcurrent2 = (BST<KeyValue<K, V>>)oOldArray[i];

                    alBSTcurrent2.Iterate(dosomething, TRAVERSALORDER.IN_ORDER);

                    iBucketCount++;
                }
            }
        }


        #endregion
        //===========================================================================================

        //======================================================
        #region getBST


        public override V Get(K key)
        {
            //throw new NotImplementedException();
            // The vReturn is the value to return
            V vReturn = default;
            // Get initialHash
            int initialHash = HashFunction(key);
            int iIndexValue = -1;
            // If the bucket is not null
            if (oDataArray[initialHash] != null)
            {
                // Cast the target object to an ArrayList
                BST<KeyValue<K, V>> alBSTcurrent2 = (BST<KeyValue<K, V>>)oDataArray[initialHash];

                KeyValue<K, V> kv = new KeyValue<K, V>(key, default(V));

                if (alBSTcurrent2.Find(kv) != null)
                {
                    vReturn = ((KeyValue<K, V>)alBSTcurrent2.Find(kv)).Value;
                }
                else
                {
                    throw new ApplicationException("The target is not found in the hash table!");

                }
                
            }
            
            return vReturn;
        }

        #endregion
        //==========================================================================================




        //===========================================================================================


        //public override V Get(K key)
        //{
        //    //throw new NotImplementedException();
        //    // The vReturn is the value to return
        //    V vReturn = default;
        //    // Get initialHash
        //    int initialHash = HashFunction(key);
        //    int iIndexValue = -1;
        //    // If the bucket is not null
        //    if (oDataArray[initialHash] != null)
        //    {
        //        // Cast the target object to an ArrayList
        //        ArrayList alCurrent = (ArrayList)oDataArray[initialHash];
        //        // Create en intance of KeyValue pair out of key and default value of V
        //        // Method 1: indexof
        //        iIndexValue = alCurrent.IndexOf(new KeyValue<K, V>(key, default(V)));
        //        //Check the index of the newly create Key/Value pair in the ArrayList
        //        if (iIndexValue >= 0)
        //        {
        //            vReturn = ((KeyValue<K, V>)alCurrent[iIndexValue]).Value;
        //        }
        //        // Method 2: foreach
        //        //foreach(KeyValuePair<K,V> kv in alCurrent)
        //        //{
        //        //    iIndexValue++;
        //        //    if (kv.Key.Equals(key))
        //        //    {
        //        //        vReturn = kv.Value;
        //        //        break;
        //        //    }
        //        //}
        //    }
        //    // If return index is -1 throw an exception
        //    if (iIndexValue < 0)
        //    {
        //        throw new ApplicationException("The target is not found in the hash table!");
        //    }
        //    // Return vReturn
        //    return vReturn;
        //}



        //====================================================================================

        //==========================================================================================
        #region RemoveBST


        public override void Remove(K key)
        {
            // Get initialHash
            int initialHash = HashFunction(key);
            int iIndexValue = -1;
            // If the bucket is not null
            if (oDataArray[initialHash] != null)
            {
                // Cast the target object to an ArrayList
                KeyValue<K, V> kv = new KeyValue<K, V>(key, default(V));

                BST<KeyValue<K, V>> alBSTcurrent2 = (BST<KeyValue<K, V>>)oDataArray[initialHash];

                
                if (alBSTcurrent2.Find(kv) != null)
                {
                    alBSTcurrent2.Remove(kv);
                    
                    iCount--;
                    if (alBSTcurrent2.Count == 0)
                    {
                        oDataArray[initialHash] = null;
                        
                        iBucketCount--;
                    }
                }
                else
                {
                    throw new ApplicationException("The target is not found in the hash table!");

                }
            }
        }

        #endregion
        //===========================================================================================

        //====================================================================================
        //public override void Remove(K key)
        //{
        //    // Get initialHash
        //    int initialHash = HashFunction(key);
        //    int iIndexValue = -1;
        //    // If the bucket is not null
        //    if (oDataArray[initialHash] != null)
        //    {
        //        // Cast the target object to an ArrayList
        //        ArrayList alCurrent = (ArrayList)oDataArray[initialHash];
        //        // Create en intance of KeyValue pair out of key and default value of V
        //        iIndexValue = alCurrent.IndexOf(new KeyValue<K, V>(key, default(V)));
        //        //Check the index of the newly create Key/Value pair in the ArrayList
        //        if (iIndexValue >= 0)
        //        {
        //            alCurrent.RemoveAt(iIndexValue);
        //            //Number of items in Hashtable
        //            iCount--;
        //            if (alCurrent.Count == 0)
        //            {
        //                oDataArray[initialHash] = null;
        //                //Number of arrayList (means that arrayList has values stored from Hash table)
        //                iBucketCount--;
        //            }
        //        }
        //    }
        //    // If return index is -1 throw an exception
        //    if (iIndexValue < 0)
        //    {
        //        throw new ApplicationException("The target is not found in the hash table!");
        //    }
        //}


        #region clearBST
        public override void Clear()
        {
            oDataArray = new object[iInitialSize];
            iCount = 0;
            iBucketCount = 0;
            iNumCollission = 0;
        }


        #endregion


        //public override string ToString()
        //{
        //    StringBuilder sb = new StringBuilder();
        //    for (int i = 0; i < oDataArray.Length; i++)
        //    {
        //        sb.Append("Bucket# " + i + ": ");
        //        if (oDataArray[i] != null)
        //        {
        //            ArrayList alCurrent = (ArrayList)oDataArray[i];
        //            foreach (KeyValue<K, V> kv in alCurrent)
        //            {
        //                sb.Append(kv.Value.ToString() + " --> ");
        //            }
        //            sb.Remove(sb.Length - 5, 5);
        //        }
        //        sb.Append("\n");
        //    }
        //    return sb.ToString();
        //}


        //===========================================================================================
        //===========================================================================================
        //===========================================================================================
        //===========================================================================================
        #region tostringBST

        StringBuilder sb = new StringBuilder();


        void dosomething2(KeyValue<K, V> kv)
        {
            //this.Add(kv.Key, kv.Value);
            sb.Append(kv.Value.ToString() + " --> ");
            //Console.Write(kv + " ");

        }

        public override string ToString()
        {
            sb = new StringBuilder();

            for (int i = 0; i < oDataArray.Length; i++)
            {
                sb.Append("Bucket# " + i + ": ");
                if (oDataArray[i] != null)
                {
                   
                    BST<KeyValue<K, V>> alBSTcurrent2 = (BST<KeyValue<K, V>>)oDataArray[i];

                    alBSTcurrent2.Iterate(dosomething2, TRAVERSALORDER.IN_ORDER);
                 
                    sb.Remove(sb.Length - 5, 5);
                }
                sb.Append("\n");
            }
            return sb.ToString();
        }

        #endregion

        //===========================================================================================
        //===========================================================================================

        #region IEnumeratorBST

        public override IEnumerator<V> GetEnumerator()
        {
            return new ChainEnumerator(this);
        }
        private class ChainEnumerator : IEnumerator<V>
        {
            private ChainingHT<K, V> parent;


            private int iCurrentBucket = -1;
            private int iCurrentKv = -1;

            public V Current
            {
                get
                {


                    BST<KeyValue<K, V>> bst = (BST<KeyValue<K, V>>)parent.oDataArray[iCurrentBucket];

                    IEnumerator<KeyValue<K, V>> enumerator = bst.GetEnumerator();

                    for(int i = 0; i<=iCurrentKv; i++)
                    {
                        enumerator.MoveNext();

                    }

                    return enumerator.Current.Value;
                    
                }
            }
            
            object IEnumerator.Current => this.Current;

            public ChainEnumerator(ChainingHT<K, V> chainingHT)
            {
                this.parent = chainingHT;
                this.iCurrentBucket = -1;
                this.iCurrentKv = -1;
               
            }
            public void Dispose()
            {
                this.parent = null;
                iCurrentBucket = -1;
                iCurrentKv = -1;

            }
            public void Reset()
            {


                iCurrentBucket = -1;
                iCurrentKv = -1;
            }
            public bool MoveNext()
            {
                bool bMoved = false;
                //Try to move to the next ArrayList, if all buckets are empty, return false
                if (iCurrentBucket == -1)
                {
                    if (FindNextBST() == false)
                    {
                        return false;
                    }
                }
                //Move to the next elemnet in the ArrayList

                ++iCurrentKv;
                //Get a reference to the current ArrayList
                BST<KeyValue<K, V>> alCurrent = (BST<KeyValue<K, V>>)(parent.oDataArray[iCurrentBucket]);
                //If at the end of the arraylist
                if (iCurrentKv == alCurrent.Count)
                {
                    //Attempt to find the next arraylist
                    bMoved = FindNextBST();
                    if (bMoved)
                    {
                        //Move to next arraylist, therefore reinitialize the row count
                        iCurrentKv = 0;
                    }
                    else
                    {
                        //Could not move, so point at the previous item
                        iCurrentKv--;
                    }
                }
                //Not at the end of arraylist
                else
                {
                    bMoved = true;
                }
                return bMoved;
            }
            private bool FindNextBST()
            {
                bool bMoved = false;
                int iTempt = iCurrentBucket;
                while (!bMoved && iTempt < parent.oDataArray.Length - 1)
                {
                    iTempt++;
                    if (parent.oDataArray[iTempt] != null)
                    {
                        bMoved = true;
                        iCurrentBucket = iTempt;
                    }
                }
                return bMoved;
            }
        }

        #endregion

        //===========================================================================================
        //===========================================================================================



        //public override IEnumerator<V> GetEnumerator()
        //{
        //    return new ChainEnumerator(this);
        //}
        //private class ChainEnumerator : IEnumerator<V>
        //{
        //    private ChainingHT<K, V> parent;
        //    private int iCurrentBucket = -1;
        //    private int iCurrentKv = -1;
        //    public V Current
        //    {
        //        get
        //        {
        //            return (
        //                      (KeyValue<K, V>)
        //                         (
        //                             (ArrayList)(parent.oDataArray[iCurrentBucket])
        //                         )[iCurrentKv]
        //                   ).Value;
        //        }
        //    }
        //    //public V Current => (
        //    //                        (KeyValue<K,V>)
        //    //                            (
        //    //                                (ArrayList)(parent.oDataArray[iCurrentBucket])
        //    //                            )[iCurrentKv]
        //    //                    ).Value;
        //    //object IEnumerator.Current => this.Current;
        //    object IEnumerator.Current =>
        //                  (
        //                     (KeyValue<K, V>)
        //                        (
        //                            (ArrayList)(parent.oDataArray[iCurrentBucket])
        //                        )[iCurrentKv]
        //                  ).Value;
        //    public ChainEnumerator(ChainingHT<K, V> chainingHT)
        //    {
        //        this.parent = chainingHT;
        //        this.iCurrentBucket = -1;
        //        this.iCurrentKv = -1;
        //    }
        //    public void Dispose()
        //    {
        //        this.parent = null;
        //        iCurrentBucket = -1;
        //        iCurrentKv = -1;
        //    }
        //    public void Reset()
        //    {
        //        iCurrentBucket = -1;
        //        iCurrentKv = -1;
        //    }
        //    public bool MoveNext()
        //    {
        //        bool bMoved = false;
        //        //Try to move to the next ArrayList, if all buckets are empty, return false
        //        if (iCurrentBucket == -1)
        //        {
        //            if (FindNextArrayList() == false)
        //            {
        //                return false;
        //            }
        //        }
        //        //Move to the next elemnet in the ArrayList
        //        ++iCurrentKv;
        //        //Get a reference to the current ArrayList
        //        ArrayList alCurrent = (ArrayList)(parent.oDataArray[iCurrentBucket]);
        //        //If at the end of the arraylist
        //        if (iCurrentKv == alCurrent.Count)
        //        {
        //            //Attempt to find the next arraylist
        //            bMoved = FindNextArrayList();
        //            if (bMoved)
        //            {
        //                //Move to next arraylist, therefore reinitialize the row count
        //                iCurrentKv = 0;
        //            }
        //            else
        //            {
        //                //Could not move, so point at the previous item
        //                iCurrentKv--;
        //            }
        //        }
        //        //Not at the end of arraylist
        //        else
        //        {
        //            bMoved = true;
        //        }
        //        return bMoved;
        //    }
        //    private bool FindNextArrayList()
        //    {
        //        bool bMoved = false;
        //        int iTempt = iCurrentBucket;
        //        while (!bMoved && iTempt < parent.oDataArray.Length - 1)
        //        {
        //            iTempt++;
        //            if (parent.oDataArray[iTempt] != null)
        //            {
        //                bMoved = true;
        //                iCurrentBucket = iTempt;
        //            }
        //        }
        //        return bMoved;
        //    }
        //}
    }
}
