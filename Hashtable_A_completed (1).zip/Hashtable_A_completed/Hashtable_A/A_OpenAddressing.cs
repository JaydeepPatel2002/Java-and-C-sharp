﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_A
{
    public abstract class A_OpenAddressing<K, V> : A_Hashtable<K, V>
        where K : IComparable<K> where V : IComparable<V>
    {
        protected abstract int GetIncrement(int iAttempt, K key);

        protected PrimeNumber pn = new PrimeNumber();

        public A_OpenAddressing()
        {
            oDataArray = new object[pn.GetNextPrime()];
            iCount = 0;
            iNumCollission = 0;
            dLoadFactor = 0.72;
        }

        public bool IsOverload()
        {
            return (iCount / (double)HTSize) > dLoadFactor;
        }

        public override void Remove(K key)
        {
            //get hashcode
            int iInitalHash = HashFunction(key);

            //set current location that you will try first
            int iCurrentLocation = iInitalHash;

            int iAttempt = 0;

            bool found = false;

            while (!found && oDataArray[iCurrentLocation] != null)
            {

                if (oDataArray[iCurrentLocation].GetType() == typeof(KeyValue<K, V>))
                {
                    KeyValue<K, V> kv = (KeyValue<K, V>)oDataArray[iCurrentLocation];
                    if (kv.Key.CompareTo(key) == 0)
                    {
                        found = true;
                        oDataArray[iCurrentLocation] = new Tombstone();
                        iCount--;
                    }
                }

                iCurrentLocation = iInitalHash + GetIncrement(++iAttempt, key);
                iCurrentLocation = iCurrentLocation % HTSize;

            }
            if (found == false)
            {
                throw new ApplicationException("Key does not exist in hashtable ");
            }


        }

        public override void Add(K key, V vValue)
        {
            //How many attempts were made to increment
            int iAttempt = 1;
            //Get the initial hash of the key
            int iInitialHash = HashFunction(key);
            //The current location
            int iCurrentLocation = iInitialHash;
            //Wrap the key and value in a key-value pair object.
            KeyValue<K, V> kvNew = new KeyValue<K, V>(key, vValue);
            //Position to add
            int iPositionToAdd = -1;
            //Find an empty location to add the current item (tombstone or a null).
            while (oDataArray[iCurrentLocation] != null)
            {
                //If it is a keyvalue
                if (oDataArray[iCurrentLocation].GetType() == typeof(KeyValue<K, V>))
                {
                    //Does the current key-value contain the same key as the item we are adding.
                    KeyValue<K, V> kv = (KeyValue<K, V>)oDataArray[iCurrentLocation];
                    //Test the two keyvalues
                    if (kv.Equals(kvNew))
                    {
                        throw new ApplicationException("Item already exists");
                    }
                }
                else //It is tombstone
                {
                    //If this is the first tombstone on the collision chain, record its position.
                    if (iPositionToAdd == -1)
                    {
                        iPositionToAdd = iCurrentLocation;
                    }
                }
                //Keep going - check the next location
                //Increment to the next location
                iCurrentLocation = iInitialHash + GetIncrement(iAttempt++, key);
                //Loop back to the top of the table if we fall off the bottom.
                iCurrentLocation %= HTSize;
                //For stats
                iNumCollission++;
            }
            //Done looping - hit a null.  Ready to add the key-value
            //If there are no tombstones
            if (iPositionToAdd == -1)
            {
                //Add at the end of the collision chain - the null
                iPositionToAdd = iCurrentLocation;
            }
            //Add the key-value to the current location
            oDataArray[iPositionToAdd] = kvNew;
            //Increment the count
            iCount++;
            //if the hashtable is overloaded, expand it.
            if (IsOverload())
            {
                ExpandHashTable();
            }
        }


        //public override void Add(K key, V vValue)
        //{
        //    int iInitalHash = HashFunction(key);

        //    int iCurrentLocation = iInitalHash;

        //    int iAttempt = 0;

        //    int iPositionToAdd = -1;

        //    KeyValue<K, V> kvNew = new KeyValue<K, V>(key, vValue);

        //    while (oDataArray[iCurrentLocation] != null)
        //    {
        //        KeyValue<K, V> kv = (KeyValue<K, V>)oDataArray[iCurrentLocation];

        //        if (kv.GetType() == typeof(KeyValue<K, V>))
        //        {
        //            if (kv.Key.CompareTo(key) == 0)
        //            {
        //                throw new ApplicationException("Key already exists in hashtable");
        //            }
        //        }
        //        else
        //        {
        //            if (iPositionToAdd == -1)
        //            {
        //                iPositionToAdd = iCurrentLocation;
        //            }
        //            iCurrentLocation = iInitalHash + GetIncrement(++iAttempt, key);
        //            iCurrentLocation %= HTSize;
        //            iNumCollission++;
        //        }
        //        if (iPositionToAdd == -1) //if we never run into tombstone
        //            iPositionToAdd = iCurrentLocation;

        //        oDataArray[iPositionToAdd] = kvNew;
        //        iCount++;

        //        if (IsOverload())
        //        {
        //            ExpandHashTable();
        //        }

        //    }


        //}

        //public void ExpandHashTable()
        //{

        //    //create local reference to old hashtable
        //    //create a new array twice the size of old hashtable
        //    //copy contents into new hashtable
        //    object[] oOldTable = oDataArray;
        //    oDataArray = new object[pn.GetNextPrime()];
        //    iCount = 0;
        //    iNumCollission = 0;

        //    for (int i = 0; i < oOldTable.Length; i++)
        //    {
        //        if (oOldTable[i].GetType() == typeof(KeyValue<K, V>))
        //        {
        //            KeyValue<K, V> kv = (KeyValue<K, V>)oOldTable[i];
        //            this.Add(kv.Key, kv.Value);
        //        }

        //    }

        //}


        //====================


        private void ExpandHashTable()
        {
            //Create a local reference and point to the existing data array
            object[] oOldArray = oDataArray;
            //Create a new array with size generated by our prime number class
            oDataArray = new object[pn.GetNextPrime()];
            //Reset any attributes if necessary
            iCount = 0;
            iNumCollission = 0;
            //Take data from old array and put it in the new one.
            for (int i = 0; i < oOldArray.Length; i++)
            {
                if (oOldArray[i] != null)
                {
                    //Test if it is a key-value (might be a tombstone)
                    if (oOldArray[i].GetType() == typeof(KeyValue<K, V>))
                    {
                        KeyValue<K, V> kv = (KeyValue<K, V>)oOldArray[i];
                        //Add to the new array
                        this.Add(kv.Key, kv.Value);
                    }
                }
            }
        }

        //=======================


        public override V Get(K key)
        {
            V vReturn = default;
            //get key
            int iInitialHash = HashFunction(key);
            int iCurrentLocation = iInitialHash;
            int iAttempt = 1;
            bool found = false;
            while (!found && oDataArray[iCurrentLocation] != null)
            {
                if (oDataArray[iCurrentLocation].GetType() == typeof(KeyValue<K, V>))
                {
                    KeyValue<K, V> kv = (KeyValue<K, V>)oDataArray[iCurrentLocation];
                    if (kv.Key.CompareTo(key) == 0)
                    {
                        found = true;
                        oDataArray[iCurrentLocation] = new Tombstone();
                        iCount--;
                    }
                }
                //increment to new location
                iCurrentLocation = iInitialHash + GetIncrement(++iAttempt, key);
                iCurrentLocation = iCurrentLocation % HTSize;
            }
            if (found == false)
            {
                throw new ApplicationException("Key does not exist in hashtable ");
            }
            return vReturn;
        }
        public override String ToString()
        {
            StringBuilder sReturn = new StringBuilder();
            for (int i = 0; i < oDataArray.Length; i++)
            {
                if (oDataArray[i] != null)
                {
                    if (oDataArray[i].GetType() == typeof(KeyValue<K, V>))
                    {
                        KeyValue<K, V> kv = (KeyValue<K, V>)oDataArray[i];
                        sReturn.Append(kv.Value.ToString() + " IH= " + HashFunction(kv.Key));
                    }
                    else
                    {
                        sReturn.Append("Tombstone");
                    }
                    sReturn.Append("\n");
                }
            }
            return sReturn.ToString();
        }
       

        private class htEnumerator : IEnumerator<V>
        {
            private A_OpenAddressing<K, V> parent;
            private int iCurrent = -1;

            public htEnumerator(A_OpenAddressing<K, V> ht)
            {
                this.parent = ht;

            }

            public V Current => ((KeyValue<K, V>)parent.oDataArray[iCurrent]).Value;

            object IEnumerator.Current => this.Current;
            public void Dispose()
            {
                //set all values to null
                parent = null;
                iCurrent = -1;
            }
            public void Reset()
            {
                //reset all values
                iCurrent = -1;

            }
            public void MoveNext()
            {
                //increment iCurrent by one till we find null or tombstone
                iCurrent++;
                //trace if we found a next item in the hashtable
                bool bFound = false;
                while (!bFound && iCurrent < parent.HTSize) //basically length
                {
                    //if the current item is not null and the corresponding object is not a tombstone
                    if (parent.oDataArray[iCurrent] != null || parent.oDataArray[iCurrent].GetType() == typeof(Tombstone))
                    {
                        ++iCurrent;
                    }
                    else
                    {
                        bFound = true;
                        break;
                    }
                    //    if (parent.oDataArray[iCurrent].GetType() == typeof(KeyValue<K, V>))
                    //    {
                    //        bFound = true;
                    //    }
                    //}
                    //iCurrent++;
                }
            }

            bool IEnumerator.MoveNext()
            {
                throw new NotImplementedException();
            }
        }

        public override IEnumerator<V> GetEnumerator()
        {
            //Return an instance of your internal enumerator class
            return new htEnumerator(this);
        }



        public override void Clear()
        {
            oDataArray = new object[HTSize];
            iCount = 0;
            
            iNumCollission = 0;
            dLoadFactor = 0.72;

        }

        public  String ToStrings()
        {
            StringBuilder sb = new StringBuilder();

            for(int i = 0; i < oDataArray.Length; i++)
            {
                sb.Append("Bucket number :" + i + " :  ");

                if (oDataArray[i] != null)
                {
                    ArrayList alCurrent = (ArrayList) oDataArray[i];

                    foreach(KeyValue<K, V> kv in alCurrent)
                    {
                        sb.Append(kv.Value.ToString() + "  --> ");
                    }
                    sb.Remove(sb.Length - 5, 5);

                }
                sb.Append("\n");

            }
            return sb.ToString();
        }



    }
}