﻿

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;

namespace Hashtable_A
{
    internal class Program 
    {

        static void LoadDataFromFile(A_Hashtable<Person, Person> ht)
        {
            StreamReader sr = new StreamReader(File.Open("People.txt", FileMode.Open));

            String sInput = "";


            try
            {
                while ((sInput = sr.ReadLine()) != null)
                {
                    char[] cArray = { ' ' };
                    string[] sArray = sInput.Split(cArray);

                    int iSSn = Int32.Parse(sArray[0]);

                    Person p = new Person(iSSn, sArray[2], sArray[1]);


                    ht.Add(p, p);





                }
            }
            catch (ApplicationException ex)
            {
                Console.WriteLine("hello error" + ex.Message);
            }
        }

        //static void LoadDataFromFile(A_Hashtable<Person, Person> ht)
        //{
        //    StreamReader sr = new StreamReader(File.Open("People.txt", FileMode.Open));

        //    String sInput = "";


        //    try
        //    {
        //        while((sInput = sr.ReadLine()) != null)
        //        {
        //            char[] cArray = {' '};
        //            string[] sArray = sInput.Split(cArray);

        //            int iSSn = Int32.Parse(sArray[0]);

        //            Person p = new Person(iSSn, sArray[2], sArray[1]);


        //            ht.Add(p, p);



        //        }
        //    }
        //    catch(ApplicationException ex)
        //    {
        //        Console.WriteLine("hello error" + ex.Message);
        //    }
        //}

        static void LoadDataFromFileAndRemove(A_Hashtable<Person, Person> ht)
        {
            StreamReader sr = new StreamReader(File.Open("People.txt", FileMode.Open));
            string sInput = "";
            ArrayList al = new ArrayList();
            int iCount = 0;
            try
            {
                //Read a line from the file
                while ((sInput = sr.ReadLine()) != null)
                {
                    try
                    {
                        char[] cArray = { ' ' };
                        string[] sArray = sInput.Split(cArray);
                        int iSSN = Int32.Parse(sArray[0]);
                        Person p = new Person(iSSN, sArray[2], sArray[1]);
                        ht.Add(p, p);
                        if (iCount % 10 == 0)
                        {
                            al.Add(p);
                        }
                        iCount++;
                    }
                    catch (ApplicationException ae)
                    {
                        Console.WriteLine("Exception: " + ae.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Count before removing: " + ht.Count);
            //Remove every tenth person that is actually in the list.
            try
            {
                foreach (Person p in al)
                {
                    ht.Remove(p);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Count after removing: " + ht.Count);
            sr.Close();
        }


        static void TestHT(A_Hashtable<Person, Person> ht)
        {
            LoadDataFromFile(ht);
            Console.WriteLine("Hash table type" + ht.GetType().ToString());

            Console.WriteLine("# of People = " + ht.Count);
            Console.WriteLine("# of Collissions: " + ht.NumCollission);
        }













        static void TestAdd(A_Hashtable<int, string> ht)
        {
            try
            {
                ht.Add(123, "niyat");
                ht.Add(133, "vipul");
                ht.Add(143, "ravi");
                ht.Add(153, "raj");
                //ht.Add(127, "Ron");
                //ht.Add(128, "jaydeep1");
                //ht.Add(129, "jaydeep2");
                //ht.Add(120, "jaydeep3");
                Console.WriteLine("--> " + ht.ToString());
                Console.WriteLine("Number of collisions " + ht.NumCollission);



            }
            catch (ApplicationException ex)
            {
                Console.WriteLine(ex.Message);  

            }
        }

        static void Main(string[] args)
        {

            ChainingBST<Person, Person> chObj = new ChainingBST<Person, Person>();

            TestHT(chObj);






            ChainingBST<int, String> linearobj = new ChainingBST<int, String>();
            
            //Console.WriteLine( linearobj.ToString());
            TestAdd(linearobj);
            Console.WriteLine("=====================================");
            Console.WriteLine(default(KeyValue<int, String>) ==  null);
            Console.WriteLine(linearobj.Get(153));


            IEnumerator<Person> myObj = chObj.GetEnumerator();
            while (myObj.MoveNext())
            {
               
                Console.WriteLine(myObj.Current.ToString());     
            }


            linearobj.Remove(133);
            //Console.WriteLine(linearobj.Get(133));

            Console.WriteLine(linearobj.ToString());
            Quadractic<Person, Person> quadratic = new Quadractic<Person, Person>();

            //LoadDataFromFileAndRemove(quadratic);

            Console.WriteLine(quadratic.ToString());


        }
    }
}
