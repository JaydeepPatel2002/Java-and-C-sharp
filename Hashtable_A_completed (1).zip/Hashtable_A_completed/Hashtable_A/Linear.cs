﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_A
{
    internal class Linear<K,V> : A_OpenAddressing<K,V>
        where V : IComparable<V>
        where K : IComparable<K>
    {
        protected override int GetIncrement(int iAttempt, K key)
        {
            return iAttempt;
        }
    }
}
