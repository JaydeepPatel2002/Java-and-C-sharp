﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_A
{
    internal class Tombstone
    {
        /*
         The reason why we need this empty class 
        When we try to find bob and we cant find him in that location, we require this
        We continue until we reach null bucket and then we stop, The tombstone obj is for continuation in collision chain. We assign
        tombstone object to the non empty current object.
        
        Its a placeholder
        
        when we remove one record, we assign it to be tombstone instead of null since we only assign null to the end!
         */
    }
}
