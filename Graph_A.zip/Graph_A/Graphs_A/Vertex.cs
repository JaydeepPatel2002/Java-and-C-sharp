﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphs_A
{
    public class Vertex<T> : IComparable<Vertex<T>>
        where T : IComparable<T>
    {
        #region attributes
        private T data;
        private int index;


        #endregion


        #region constructor


        public Vertex(T data, int index)
        {
            this.data = data;
            this.index = index;
        }
        #endregion

        #region properties

        public T Data { get { return data; } }

        public int Index { get { return index; } 
        
                           set { index = value; }
        }


        #endregion

        public int CompareTo(Vertex<T> other)
        {
            return this.data.CompareTo(other.data);
        }

        public override string ToString()
        {
            return "["  + data + "(" + index + ")]";
        }


        public override bool Equals(object obj)
        {
            //return this.CompareTo( (Vertex<T>)obj ) == 0;

            return this.data.CompareTo(((Vertex<T>)obj).Data) == 0;

        }


    }




}
