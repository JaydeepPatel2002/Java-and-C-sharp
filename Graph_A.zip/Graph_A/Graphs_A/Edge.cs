﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphs_A
{
    public class Edge<T> : IComparable<Edge<T>>
        where T : IComparable<T>
    {
        #region Attributes

        private Vertex<T> from;
        private Vertex<T> to;
        bool isWeighted;

        private double weight;


        #endregion

        #region Constructors

        public Edge(Vertex<T> from, Vertex<T> to)
        {
            this.from = from;
            this.to = to;
            this.weight = double.PositiveInfinity;
            this.isWeighted = false;
        }

        public Edge(Vertex<T> from, Vertex<T> to, double weight)
        {
            this.from = from;
            this.to = to;
            this.weight = weight;
            this.isWeighted = true;
        }

        public Edge(Vertex<T> from, Vertex<T> to, bool isWeighted) : this(from, to)
        {
            this.from = from;
            this.to = to;
            this.isWeighted = isWeighted;
        }

        public Edge(Vertex<T> from, Vertex<T> to, bool isWeighted, double weight)
        {
            this.from = from;
            this.to = to;
            this.isWeighted = isWeighted;
            this.weight = weight;
        }

        public int CompareTo(Edge<T> other )
        {
            int result = 0;
            if(this.isWeighted && other.isWeighted)
            {
                result = this.weight.CompareTo(other.weight);
            }

            if(result == 0)
            {
                //Compare the from vertices 
                result = from.CompareTo(other.from);

                //if from vertices are same then compare to vertices

                if(result == 0)
                {
                    result = to.CompareTo(other.to);
                }

            }

            return result;
        }

        

        #endregion

        public override bool Equals(object obj)
        {
            return this.CompareTo((Edge<T>)obj) == 0;
        }

        public override string ToString()
        {

            //Use the ternary operator to append the weight if it is exist
            return from + " to " + to + (isWeighted?", W = " + weight : "") ;
        }




    }
}
