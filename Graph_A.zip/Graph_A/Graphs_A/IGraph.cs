﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphs_A
{

    public delegate void VisitorDelegate<T> (T data);

    public interface IGraph<T> where T : IComparable<T>

    {

        #region properties

        int NumVertices { get; }

        int NumEdges { get; }

        #endregion

        #region Methods To work with vertices

        void AddVertex (T vertex);

        void RemoveVertex(T data);

        bool HasVertex(T data);

        Vertex<T> GetVertex (T data);

        //return a collection where we can loop through all vertices

        IEnumerable<Vertex<T>> EnumerateVertices();
        //return the neighbour vertices

        IEnumerable<Vertex<T>> EnumerateNeighbours();

        #endregion
        #region methods to work with edges

        void AddEdge(T from, T to);

        void AddEdge(T from, T to, double weight);

        bool HasEdge(T from, T to);

        void RemoveEdge(T from, T to);

       Edge<T> GetEdge(T from, T to);


        #endregion

        #region methods that are graph algorithms

        void BreadFirstTraversal(T start, VisitorDelegate<T> whatToDo);

        void DepthFirstTraversal(T start, VisitorDelegate<T> whatToDo);

        IGraph<T> MinimumSpanningTree();

        IGraph<T> ShortestWeightedPath(T start, T end);

        #endregion


    }
}
