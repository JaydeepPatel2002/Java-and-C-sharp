﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphs_A
{
    public abstract class AGraph<T> : IGraph<T> where T : IComparable<T>
    {
        #region ATTRIBUTES
        //store the vertices of the graph
        protected List<Vertex<T>> vertices;

        //A Dictionary is a hashTable essentially
        //it supports generic. we will use it to store a data item index into the vertices list. this will make
        // it much more efficient to lookup a vertex in the vertices list

        protected Dictionary<T, int> revLookup;
        //stores number of edges.

        protected int numEdges;
        protected int numVertices;
        protected bool isWeighted;
        // if the graph is directed
        protected bool isDirected;


        #endregion

        #region Constructors

        public AGraph()
        {
            vertices = new List<Vertex<T>>();
            revLookup = new Dictionary<T, int>();   
            numEdges = 0;
        }

        #endregion


        #region IGraph implementation

        public int NumVertices { get { return vertices.Count; } }

        public virtual int NumEdges { get { return numEdges; } }

        #endregion


        #region Vertex methods
        public bool HasVertex(T data)
        {
            return revLookup.ContainsKey(data);
        }
        public Vertex<T> GetVertex(T data)
        {
            if(!HasVertex(data))
            {
                throw new ApplicationException("vertex does not exists!!!");
            }
            
            //reverse lookup the index in the hashtable (dictionary)
            // note that c sharp overloads that [] operators for its dictionary

            int index = revLookup[data];

            return vertices[index]; 

        }
        #endregion

    }
}
