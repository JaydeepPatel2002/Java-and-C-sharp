package slotgame;

import java.util.Map;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.media.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Duration;


public class Slot extends Application {
	 int bid = 0;
	private Text txtResults = new Text("Result go here - Cash $200.0"+ bid);
	private ImageView imgSlot1 = new ImageView();
	private ImageView imgSlot2 = new ImageView();
	private ImageView imgSlot3 = new ImageView();
	private Image[] imgSource;
	final static int MAX_ICONS = 9 ;
	Timeline obAni;
	/**
	   * The main method is only needed for the IDE with limited
	   * JavaFX support. Not needed for running from the command line.
	   */
	  public static void main(String[] args) {
	    launch(args);
	  }
	  
	  int i = 0;
	  
	  Media media = new Media("https://quicksounds.com/uploads/tracks/242611924_1189879242_1915412269.mp3");
	  MediaPlayer mediaPlayer = new MediaPlayer(media);
	  
	  
	  int first;
	  int second;
	  int third ;
	  private void anim()
	  {
		   first =(int) (Math.random() * (81)) % MAX_ICONS;
		   second =(int) (Math.random() * (81)) % MAX_ICONS;
		   third =(int) (Math.random() * (81)) % MAX_ICONS;
		  
	  imgSlot1.setImage(imgSource[first]);
	  imgSlot2.setImage(imgSource[second]);
	  imgSlot3.setImage(imgSource[third]);
	  }
	  
	  private void animate()
		{
		  
		 
		  obAni = new Timeline(new KeyFrame(Duration.millis(100),e->{ 
			  
			 anim();
		  
		  
		  
		  
		  }));
			obAni.setCycleCount(10);
			obAni.play();
			obAni.setOnFinished(e->{calculate();});
			
			
			
		}
	 
	  int round = 0;
	  int count = bid;
	  private void calculate()
	  {
		 
		 
		  if (first==second || second == third || first == third ) 
		  {
			  
			  count = count + bid;
			  
			  txtResults.setText("Result go here - Cash :$"+count);
		  }
		  else if (first==second && second == third) 
		  {
			  count = 3*bid;
			  txtResults.setText("Result go here - Cash :$"+count);
		  }
		  else if(first!=second || second != third || first != third)
		  {

			  if( round==1)
			  {
				  txtResults.setText("Result go here - Cash :$"+count);
			  }
			  else if(round>1)
			  {
				  count = count - bid;
					 txtResults.setText("Result go here - Cash :$"+count);
			  }
			  
			 
		  }
		  
		 
		  
	  }
	  
	  
	  

	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		BorderPane obPane = new BorderPane();
		
//		Media media = new Media("https://quicksounds.com/uploads/tracks/242611924_1189879242_1915412269.mp3");		
//	    MediaPlayer mediaPlayer = new MediaPlayer(media);
	    
		
		//Top area - main area
		Pane obTop = new Pane();
		obPane.setTop(obTop);
		
		VBox obRight = new VBox(10);
		obPane.setRight(obRight);
		
		obRight.setPadding(new Insets(5, 5, 5, 5)); 

		
		RadioButton rb1 = new RadioButton("$1");
		RadioButton rb2 = new RadioButton("$2");
		RadioButton rb5 = new RadioButton("$5");
		RadioButton rb10 = new RadioButton("$10");
		RadioButton rb20= new RadioButton("$20");
		RadioButton rb50= new RadioButton("$50");
		RadioButton rb100= new RadioButton("$100");
		
		ToggleGroup group2 = new ToggleGroup();
		Map.of(1,rb1,
	    		2,rb2,
	    		5,rb5,
	    		10,rb10,
	    		20,rb20,
	    		50,rb50,
	    		100,rb100
	    				).
		entrySet().forEach(
	    				t->{
	    					obTop.getChildren().add(t.getValue());
	    					t.getValue().setToggleGroup(group2);
	    					t.getValue().setOnAction(e->{
	    						if(((RadioButton)e.getSource()).isSelected())
	    						{
	    							
	    							bid = (int)t.getKey();
	    							
	    							txtResults.setText("Result go here - Cash :$"+bid);
	    							System.out.println(bid);
	    						}
	    					});
	    				}
	    				);
		rb1.setLayoutX(710);
		rb2.setLayoutX(710);
		rb5.setLayoutX(710);
		rb10.setLayoutX(710);
		rb20.setLayoutX(710);
		rb50.setLayoutX(710);
		rb100.setLayoutX(710);
		rb1.setLayoutY(20);
		rb2.setLayoutY(40);
		rb5.setLayoutY(60);
		rb10.setLayoutY(80);
		rb20.setLayoutY(100);
		rb50.setLayoutY(120);
		rb100.setLayoutY(140);

		
		
		
		obPane.setRight(obRight);
		HBox obBottom = new HBox(20);
		obPane.setBottom(obBottom);
		obBottom.setAlignment(Pos.BASELINE_CENTER);
		obBottom.setPadding(new Insets(5,10,5,10));
		
		obTop.getChildren().add(txtResults);
		txtResults.setFont(Font.font("playbill",FontWeight.BOLD, FontPosture.ITALIC,25));
		txtResults.setFill(Color.GOLD);
		txtResults.setX(260);
		txtResults.setY(310);
		
		obTop.prefWidthProperty().bind(stage.widthProperty().multiply(0.78));
		obRight.prefWidthProperty().bind(stage.widthProperty().multiply(0.22));
		obTop.prefHeightProperty().bind(stage.heightProperty().multiply(0.85));
		obBottom.prefHeightProperty().bind(stage.heightProperty().multiply(0.15));
		BackgroundImage myBI = new BackgroundImage(new Image("file:images/background.jpg",687,640,false,true),
				BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,BackgroundSize.DEFAULT);
		obTop.setBackground(new Background(myBI));
		
		 obTop.setStyle
	      ("-fx-border-width: 2px; -fx-border-color: green");
		
		ImageView imgSpin = new ImageView("file:images/spin.png");
		imgSpin.setFitHeight(50);
		imgSpin.setFitWidth(50);
		Button cmdSpin = new Button("Spin",imgSpin);
		
		ImageView imgCash = new ImageView("file:images/cash.png");
		imgCash.setFitHeight(50);
		imgCash.setFitWidth(50);
		Button cmdCash = new Button("Cash Out",imgCash);
		obBottom.getChildren().addAll(cmdSpin,cmdCash);
		
		
		imgSource = new Image[MAX_ICONS];
		for(int i=0;i<imgSource.length;i++)
		{
			imgSource[i] =  new Image(String.format("file:images/%d.jpg",i+1));
		}
		
		imgSlot1.setImage(imgSource[0]);
		imgSlot1.setX(50);
		imgSlot1.setY(347);
		imgSlot1.setFitHeight(209);
		imgSlot1.setFitWidth(170);
		obTop.getChildren().add(imgSlot1);
		
		imgSlot2.setImage(imgSource[1]);
		imgSlot2.setX(260);
		imgSlot2.setY(347);
		imgSlot2.setFitHeight(209);
		imgSlot2.setFitWidth(170);
		obTop.getChildren().add(imgSlot2);
		
		imgSlot3.setImage(imgSource[2]);
		imgSlot3.setX(470);
		imgSlot3.setY(347);
		imgSlot3.setFitHeight(209);
		imgSlot3.setFitWidth(170);
		obTop.getChildren().add(imgSlot3);
		

		cmdSpin.setOnAction(e-> {	
			 mediaPlayer.seek(Duration.seconds(0));
			    mediaPlayer.play();
			    	 round++;			    	 
					animate();		
			;} );
		
		
		
		cmdCash.setOnAction(e->{ 
			
			Stage primaryStage = new Stage();
			BorderPane root = new BorderPane();
		Scene scene = new Scene(root,200,200);
		root.setBorder(new Border(new BorderStroke(Color.BLACK, 
	            BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
		
		Text result = new Text();
		
		
		
		
		
		//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.setWidth(600);
		primaryStage.setHeight(600);
		primaryStage.show();
		 root.getChildren().add(result);
		 result.setText("okkkkkkkkk");
		 
		 result.setText("YOUR PAYABLE BILL IS :"+count );
		 result.setFont(Font.font ("Verdana", 20));
		 result.setFill(Color.RED);
		 result.setLayoutY(150);
		 result.setLayoutX(10); }
	
				);
		
		
		
		Scene sence = new Scene(obPane, 887,750);
		stage.setTitle("CST Slot Macine");
		stage.setScene(sence);
		stage.show();
		
	}
	  
	  
	  
}