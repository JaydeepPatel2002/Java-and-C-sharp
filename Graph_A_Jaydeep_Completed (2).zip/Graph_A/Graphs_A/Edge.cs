﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphs_A
{
    public class Edge<T> : IComparable<Edge<T>>
        where T : IComparable<T>
    {
        #region Attributes
        private Vertex<T> from;
        private Vertex<T> to;
        private bool isWeighted;
        private double weight;
        #endregion

        #region Properties
        public Vertex<T> From
        {
            get { return from; }
        }
        public Vertex<T> To { get => to; }
        public bool IsWeighted => isWeighted;
        public double Weight => weight;
        #endregion

        #region Constructors
        /// <summary>
        /// If not weighted, we will store positeve infinity for weight
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        public Edge(Vertex<T> from, Vertex<T> to)
        {
            this.from = from;
            this.to = to;
            this.weight = double.PositiveInfinity;
            this.isWeighted = false;
        }

        /// <summary>
        /// The constructor accepts from, to, and weight
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="weight"></param>
        public Edge(Vertex<T> from, Vertex<T> to, double weight)
        {
            this.from = from;
            this.to = to;
            this.weight = weight;
            this.isWeighted = true;
        }

        /// <summary>
        /// This constructor is to take from, to, isWeighted, weight
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="isWeighted"></param>
        /// <param name="weight"></param>
        public Edge(Vertex<T> from, Vertex<T> to, bool isWeighted, double weight)
        {
            this.from = from;
            this.to = to;
            this.isWeighted = isWeighted;
            this.weight = weight;
        }
        #endregion

        public int CompareTo(Edge<T> other)
        {
            int result = 0;
            // Don't compare weight unless both edges are weighted
            if(this.isWeighted && other.isWeighted)
            {
                result = this.weight.CompareTo(other.weight);
            }

            //What if the edges have the same weight
            if(result == 0)
            {
                // Compare the From vertices
                result = from.CompareTo(other.from);
                // if the from vertices are the same
                if(result == 0)
                {
                    //Compare the to verties
                    result=to.CompareTo(other.to);
                }
            }
            return result;
        }

        public override bool Equals(object obj)
        {
            return this.CompareTo((Edge<T>) obj) == 0;
        }

        public override string ToString()
        {
            // User the ternary operator to append the weight if it is exists
            return from + " to " + to + (isWeighted? ", W = " + weight : "");
        }
    }
}
