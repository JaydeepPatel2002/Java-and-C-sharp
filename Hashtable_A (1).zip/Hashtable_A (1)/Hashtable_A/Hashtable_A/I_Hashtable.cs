﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_A
{
    //K --> Generic value representing the daya type of key
    //V --> Generic value representing the daya type of value

    internal interface I_Hashtable<K, V> : IEnumerable<V> where K : IComparable<K>
    {
        //<summary>
        //Return a value from the hashtable
        //</summary>
        //<param name = "key" > The key of the value in the hash table </param>
        //<param name = "value" > The value to store </param>
        //<return> The value associated with the key </return>

        void Add(K key, V value);

        //<summary>
        //Return a key/value from the hashtable
        //</summary>
        //<param name = "key" > The key of the value in the hash table </param>

        void Remove(K key);

        //<summary>
        //Remove all key/value pair in the Hash table
        //</summary>

        void Clear();
    }
}

        
    

