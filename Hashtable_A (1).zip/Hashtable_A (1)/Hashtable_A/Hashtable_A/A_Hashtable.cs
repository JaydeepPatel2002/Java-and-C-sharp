﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_A
{
    public abstract class A_Hashtable<K, V> : I_Hashtable<K, V>
        where K : IComparable<K> where V : IComparable<V>
    {

        #region Attributes
        //in the case of chaining, this array will store references to a secondary data structure
        //in this case of open-addressing (probing algorithms) the array will store the key-value pair objects
        //in this course, we will use list
        protected object[] oDataArray;

        protected int iCount;
        //Collissions count - used for stats purpose
        protected int iNumCollission = 0;

        //load factor - used to set the maximum percentage that we will
        protected double dLoadFactor = 0.72;
        #endregion

        #region Properties
        public int Count
        {
            get { return iCount; }
        }

        public int NumCollission { get { return iNumCollission; } }

        public int HTSize
        {
            get { return oDataArray.Length; }
        }
        #endregion

        #region Helper Methods
        protected int HashFunction(K key)
        {
            return Math.Abs(key.GetHashCode() % HTSize);
        }

        #endregion

        public abstract void Add(K key, V vValue);

        public void Clear()
        {
            //reset everything to default
            oDataArray = new object[HTSize];
            iCount = 0;
            iNumCollission = 0;
            dLoadFactor = 0.72;
        }

        public abstract void Remove(K key);
        public abstract V Get(K key);
        public abstract IEnumerator<V> GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() //calling the same GetEnumerator, its a non generic way of doing it
        {
            return this.GetEnumerator();
        }

        
    }
}
