﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_A
{
    internal class 
        KeyValue<K, V> : IComparable<KeyValue<K, V>>
        where K : IComparable<K> where V : IComparable<V>
    {
        //Store key/value pair
        private K key;
        private V vValue; //since lowercase value is a keyword

        public KeyValue(K key, V vValue)
        {
            this.key = key;
            this.vValue = vValue;
        }
        //getters
        public K Key
        {
            get { return key; }
        }

        public V Value
        {
            get { return vValue; }
        }

        public int CompareTo(KeyValue<K, V> other)
        {
            throw new NotImplementedException();
        }

        public override bool Equals(Object obj)
        {
            KeyValue<K, V> kv = (KeyValue<K, V>) obj;
            return this.Key.CompareTo(kv.Key) == 0;
        }

    }
    
}
