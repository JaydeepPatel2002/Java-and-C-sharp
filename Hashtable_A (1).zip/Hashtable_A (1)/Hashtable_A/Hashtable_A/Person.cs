﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_A
{
    internal class Person : IComparable<Person>
    {
        int ssn = 0;
        string sFirstName = "";
        string sLastName = "";

        int iCount = 1;

        public Person(int ssn, string sFirstName, string sLastName)
        {
            this.ssn = ssn;
            this.sFirstName = sFirstName;
            this.sLastName = sLastName;
        }


        public int SSN
        {
            get { return ssn; }
        }

        public string FirstName
            { get { return sFirstName; } }
        public string LastName
            { get { return sLastName; } }
        public int Count
            { get { return iCount; } }

        public override int GetHashCode()
        {
            char[] cChars = ssn.ToString().ToCharArray();
            int iHashCode = 0;
            const int iPrime = 31;

            for(int i = 0; i < cChars.Length; i++)
            {
                iHashCode += (iPrime * iHashCode + cChars[i]);
            }

            return iHashCode;
        }


        public override string ToString()
        {
            return ssn.ToString() + "  " + LastName + " " + FirstName;
        }

        public override bool Equals(object obj)
        {
            Person pTemp = (Person)obj  ;


            return this.ssn.Equals(pTemp.ssn);
        }

        public int CompareTo(Person other)
        {
            return this.ssn.CompareTo(other.ssn);
        }
    }
}
