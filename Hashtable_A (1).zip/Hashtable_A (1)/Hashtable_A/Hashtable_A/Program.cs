﻿

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;

namespace Hashtable_A
{
    internal class Program
    {
        static void LoadDataFromFile(A_Hashtable<Person, Person> ht)
        {
            StreamReader sr = new StreamReader(File.Open("People.txt", FileMode.Open));

            String sInput = "";


            try
            {
                while((sInput = sr.ReadLine()) != null)
                {
                    char[] cArray = {' '};
                    string[] sArray = sInput.Split(cArray);

                    int iSSn = Int32.Parse(sArray[0]);

                    Person p = new Person(iSSn, sArray[2], sArray[1]);


                    ht.Add(p, p);



                }
            }
            catch(ApplicationException ex)
            {
                Console.WriteLine("hello error" + ex.Message);
            }
        }

        static void LoadDataFromFileAndRemove(A_Hashtable<Person, Person> ht)
        {
            StreamReader sr = new StreamReader(File.Open("People.txt", FileMode.Open));
            string sInput = "";
            ArrayList al = new ArrayList();
            int iCount = 0;
            try
            {
                //Read a line from the file
                while ((sInput = sr.ReadLine()) != null)
                {
                    try
                    {
                        char[] cArray = { ' ' };
                        string[] sArray = sInput.Split(cArray);
                        int iSSN = Int32.Parse(sArray[0]);
                        Person p = new Person(iSSN, sArray[2], sArray[1]);
                        ht.Add(p, p);
                        if (iCount % 10 == 0)
                        {
                            al.Add(p);
                        }
                        iCount++;
                    }
                    catch (ApplicationException ae)
                    {
                        Console.WriteLine("Exception: " + ae.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Count before removing: " + ht.Count);
            //Remove every tenth person that is actually in the list.
            try
            {
                foreach (Person p in al)
                {
                    ht.Remove(p);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Count after removing: " + ht.Count);
            sr.Close();
        }
















        static void TestAdd(A_Hashtable<int, string> ht)
        {
            try
            {
                ht.Add(1231231231, "prakher");
                ht.Add(99345347, "duck");
                ht.Add(8448574, "nikhil");
                ht.Add(98565322, "patel");
                Console.WriteLine( "--> " +ht.ToString());

                ht.Add(93404984, "Ron");
                Console.WriteLine("Number of collisions " + ht.NumCollission);



            }
            catch (ApplicationException ex)
            {
                Console.WriteLine(ex.Message);  

            }
        }

        static void Main(string[] args)
        {

            Linear<int, String> linearobj = new Linear<int, String>();
            TestAdd(linearobj);



            Quadractic<Person, Person> quadratic = new Quadractic<Person, Person>();

            LoadDataFromFileAndRemove(quadratic);

            Console.WriteLine(quadratic.ToString());


        }
    }
}
