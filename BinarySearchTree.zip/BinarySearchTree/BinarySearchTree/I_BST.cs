﻿using System;
using DataStructureCommon; //Add references => browse to DataStructureCommon.dll
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearchTree
{
    //Define a delegate that will point to a method that will perform some action on data member of Type T
    public delegate void ProcessData<T>(T data);

    public enum TRAVERSALORDER {PRE_ORDER, IN_ORDER, POST_ORDER};
    public interface I_BST<T> : I_Collection<T> where T : IComparable<T>
    {
        /// <summary>
        /// Given a data element, find the corresponding elements of equal value
        /// </summary>
        /// <para name="data"> The item to find</para>
        T Find(T data);

        /// <summary>
        /// Returns the height of the tree
        /// </summary>
        /// <return> The height of the tree</return>
        int Height();

        /// <summary>
        /// Similar to an enumerator, but more efficient. Also the iterate method utilizes a delegate to perform some action on each data item
        /// </summary>
        /// <para name="pd"> A delegate or function pointer to a method</para>
        /// <para name="to"> The order in which the tree is traversed</para>
        void Iterate(ProcessData<T> pd, TRAVERSALORDER to);
    }
}
