﻿namespace BinarySearchTree
{
    public class Node<T> where T : IComparable<T>
    {

        #region  

        private T data;
        private Node<T> nLeft;
        private Node<T> nRight;



        #endregion
        #region

        public Node() : this( default(T), null, null ) { }

        public Node(T data) : this(data, null, null) { }

        public Node(T data, Node<T> nLeft, Node<T> nRight)
        {
            this.data = data;
            this.nLeft = nLeft;
            this.nRight = nRight;
        }



        #endregion

        public T Data { get => data; set => data = value; }

        public Node<T> NLeft { get => nLeft; set => nLeft = value; }

        public Node<T> Right { get => nRight; set => nRight = value; }  

        public bool IsLeaf()
        {
            return this.nLeft == null && this.nRight == null;
        }



    }
}