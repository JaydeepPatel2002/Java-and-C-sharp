﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearchTree
{
    internal class BST<T>: A_BST<T>, ICloneable<T> where T : IComparable<T>
    {

        public BST()
        {
            nRoot = null;
            iCount = 0;


        }

        public T FindSmallest()
        {
            if (nRoot == null)
            {
                throw new Exception("Root is null");
            }
            else
            {
                return RecFindSmallest(nRoot);
            }
        }

        private T RecFindSmallest(Node<T> nCurrent )
        {
            if( nCurrent.NLeft == null )
            {
                return nCurrent.Data;
            }
            else
            {
                return RecFindSmallest(nCurrent.NLeft);
            }
        }

        //public T FindLarge
        public override int Height()
        {
            throw new NotImplementedException();
        }


        private T RecFind(T data, Node<T> nCurrent)
        {
            if (nCurrent == null)
            {
                return default(T);
            }
            else
            {
                if (data.CompareTo(nCurrent.Data) == 0)
                {
                    return nCurrent.Data;
                }
                else if (nCurrent.Data.CompareTo(data) < 0)
                {
                    return RecFind(data, nCurrent.Right);
                }
                else
                    return RecFind(data, nCurrent.NLeft);
            }
        }

        public T FindLargest()
        {
            if (nRoot != null)
            {
                return RecFindLargest(nRoot);
            }
            else
                throw new ApplicationException("Root is not found");
        }
        private T RecFindLargest(Node<T> nCurrent)
        {
            if (nCurrent.Right == null)
            {
                return nCurrent.Data;
            }
            else
                return RecFindLargest(nCurrent.Right);
        }

        private int RecHeight(Node<T> nCurrent)
        {
            int iHeightRight = 0;
            int iHeightLeft = 0;
            if (nCurrent.IsLeaf())
            {
                return 0;
            }
            else
            {
                if (nCurrent.NLeft != null)
                {
                    iHeightLeft = 1 + RecHeight(nCurrent.NLeft);
                }
                if (nCurrent.Right != null)
                {
                    iHeightRight = 1 + RecHeight(nCurrent.Right);
                }
                return iHeightLeft > iHeightRight ? iHeightLeft : iHeightRight;
            }

        }
        public void iterate(ProcessData<T> pd, TRAVERSALORDER to)
        {
            if (nRoot != null)
                RecIterate(nRoot, pd, to);

        }

        private void RecIterate(Node<T> nCurrent, ProcessData<T> pd, TRAVERSALORDER to)
        {
            if (to == TRAVERSALORDER.PRE_ORDER)
            {
                pd(nCurrent.Data);//Process the data
                if (nCurrent.Left != null)
                    RecIterate(nCurrent.NLeft, pd, to);

                if (nCurrent.Right != null)
                {
                    RecIterate(nCurrent.Right, pd, to);
                }
            }
            else if (to == TRAVERSALORDER.POST_ORDER)
            {
                if (nCurrent.Right != null)
                {
                    RecIterate(nCurrent.Right, pd, to);
                }

            }
            else
            {
                if (nCurrent.NLeft != null)
                    RecIterate(nCurrent, pd, to);
                if (nCurrent.Right != null)
                    RecIterate(nCurrent.Right, pd, to);

                pd(nCurrent.Data);
            }
        }

        private void RecAdd(T data, Node<T> nCurrent)
        {
            int iResult = data.CompareTo(nCurrent.Data);

            if (iResult < 0)
            {
                if(nCurrent.Right == null)
                {
                    nCurrent.Right = new Node<T>()
                }
            }

        }
        public bool MoveNext()
        {
            bool bMoved = false;
        }

        public void reset()
        {
            sNodes = new Stack<Node<T>>();

        }

        if(sNodes.Count > 0)
            {
            }


    }
}
