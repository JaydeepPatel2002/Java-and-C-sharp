﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedList
{
    internal class Program
    {
        static void TestAdd(LinkedList<int> myList)
        {
            myList.Add(3);
            myList.Add(5);
            myList.Add(7);
            myList.Add(11);
            myList.Add(14);
        }

        static void Main(string[] args)
        {
            


                LinkedList<int> myList = new LinkedList<int>();
                TestAdd(myList);

                Console.WriteLine(myList.ToString());

        }
    }
}
